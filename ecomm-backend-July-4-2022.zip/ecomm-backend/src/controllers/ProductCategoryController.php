<?php
namespace Polytropic\EcommBackend\controllers;

use Doctrine\DBAL\DriverManager;
use Exception;
use Polytropic\EcommBackend\helpers\FlashMessage;
use Polytropic\EcommBackend\helpers\Response;
use Polytropic\EcommBackend\models\ProductCategory;

class ProductCategoryController extends BaseController{
    
    private $conn;

    public function __construct()
    {
        $this->conn = DriverManager::getConnection(DATABASE_PARAMS);
    }

    public function manage(){
        $response = new Response();
        $records = [];

        try{
            $recordAction = $_POST["recordAction"] ?? false;
            if($recordAction != false){
                $recordId = $_POST["recordId"];
                switch($recordAction){
                    case "enable": {
                        ProductCategory::findById($this->conn, $recordId)
                            ->setIsEnabled(true)
                            ->save($this->conn);
                        break;
                    }
                    case "disable": {
                        ProductCategory::findById($this->conn, $recordId)
                            ->setIsEnabled(false)
                            ->save($this->conn);
                        break;
                    }
                    case "delete": {
                        ProductCategory::findById($this->conn, $recordId)
                            ->delete($this->conn);
                        break;
                    }
                }
            }
            $response->currentPage = $_GET["page"] ?? 1;
            $response->totalRecords = ProductCategory::getRecordCount($this->conn);
            $response->totalPages = ProductCategory::getTotalPages($this->conn);
            $categories = ProductCategory::getPage($this->conn, $response->currentPage);
            foreach($categories as $category){
                $parents = ProductCategory::getParentHirearchy($this->conn, $category->getId());
                $parentsArray = [];
                foreach($parents as $parent){
                    $parentsArray[] = $parent->getTitle();
                }
                $records[] = [
                    "id" => $category->getId(),
                    "title" => $category->getTitle(),
                    "parent" => empty($parentsArray) ? "---" : implode(" >> ", $parentsArray),
                    "desc" => $category->getDescription(),
                    "bannerImage" => $category->getBannerImage(),
                    "isEnabled" => $category->getIsEnabled()
                ];
            }
        }catch(Exception $e){
            $response->handleError($e);
        }
    
        $this->renderView(
            "product-category/manage",
            [
                "response" => $response,
                "pageTitle" => "Manage Product Category",
                "records" => $records
            ]
        );
    }

    public function add(){
        $response = new Response();

        try{
            $response->categories = ProductCategory::getAll($this->conn);
            if(isset($_REQUEST["formSubmitted"])){
                $parentCategory = $_POST["parentCategory"];
                $title = trim($_POST["title"]);
                $description = trim($_POST["description"]);
                $bannerImage = $_FILES["bannerImage"] ?? false;
                $isEnabled = ($_POST["isEnabled"] == "yes");

                if(empty($title) || empty($bannerImage))
                    throw new Exception("Mandatory fields found empty.");
                if($bannerImage["error"] != UPLOAD_ERR_OK)
                    throw new Exception("Failed to upload banner image.");
                $fileExtension = strtolower(pathinfo($bannerImage["name"], PATHINFO_EXTENSION));
                if(!in_array($fileExtension, ["jpg", "jpeg", "png", "gif"]))
                    throw new Exception("Banner image file must be one with following extension - jpg, jpeg, png, or, gif");
                if($bannerImage["size"] > (500 * 1024))
                    throw new Exception("Banner image file cannot execeed 500KB in size.");
                
                //moving the banner image file to uploads folder
                $fileName = uniqid("product-category-") . "." . $fileExtension;
                $filePath = UPLOAD_FOLDER . $fileName;
                if(!move_uploaded_file($bannerImage["tmp_name"], $filePath))
                    throw new Exception("Failed to save banner image.");
                
                //adding product category in database
                $record = new ProductCategory();
                $record->setTitle($title)
                    ->setDescription($description)
                    ->setBannerImage($fileName)
                    ->setIsEnabled($isEnabled)
                    ->setParentCategoryId((empty($parentCategory) ? null : $parentCategory));
                $record->insert($this->conn);
                FlashMessage::setMessage("Product Category added successfully.");
                $this->redirectToRoute("admin/product-category/manage");
            }
        }catch(Exception $e){
            $response->handleError($e);
        }

        $this->renderView(
            "product-category/add",
            [
                "response" => $response,
                "pageTitle" => "Add Product Category"
            ]
        );
    }

    public function edit(){
        $response = new Response();
        
        try{
            $response->categories = ProductCategory::getAll($this->conn);
            if(isset($_REQUEST["formSubmitted"])){
                $response->recordId = $_POST["recordId"];
                $response->formData = [
                    "title" => trim($_POST["title"]),
                    "description" => trim($_POST["description"]),
                    "parentCategory" => empty($_POST["parentCategory"]) ? null : $_POST["parentCategory"],
                    "bannerImage" => $_FILES["bannerImage"] ?? false,
                    "savedBannerImage" => $_POST["savedBannerImage"]
                ];

                if(empty($response->formData["title"]))
                    throw new Exception("Mandatory fields found empty.");
                if(!empty($response->formData["bannerImage"]["title"])){
                    $bannerImage = $response->formData["bannerImage"];
                    if($bannerImage["error"] != UPLOAD_ERR_OK)
                        throw new Exception("Failed to upload banner image");
                    $fileExtension = strtolower(pathinfo($bannerImage["name"], PATHINFO_EXTENSION));
                    if(!in_array($fileExtension, ["jpg", "jpeg", "png", "gif"]))
                        throw new Exception("Banner image file must be one with following extension - jpg, jpeg, png, or, gif");
                    if($bannerImage["size"] > (500 * 1024))
                        throw new Exception("Banner image file cannot execeed 500KB in size.");
                    $fileName = uniqid("product-category-") . "." . $fileExtension;
                    $filePath = UPLOAD_FOLDER . $fileName;
                    if(!move_uploaded_file($bannerImage["tmp_name"], $filePath))
                        throw new Exception("Failed to save banner image.");
                }
                
                $record = ProductCategory::findById($this->conn, $response->recordId);
                $record->setTitle($response->formData["title"])
                    ->setDescription($response->formData["description"])
                    ->setParentCategoryId($response->formData["parentCategory"]);
                if(!empty($response->formData["bannerImage"]["title"])){
                    $record->setBannerImage($fileName);
                }
                $record->save($this->conn);
                FlashMessage::setMessage("Record Saved Successfully!");
                $this->redirectToRoute("admin/product-category/manage");
            }else{
                $id = $_GET["id"];
                $category = ProductCategory::findById($this->conn, $id);
                $response->recordId = $id;
                $response->formData = [
                    "title" => $category->getTitle(),
                    "description" => $category->getDescription(),
                    "parentCategory" => $category->getParentCategoryId(),
                    "savedBannerImage" => $category->getBannerImage()
                ];
            }
        }catch(Exception $e){
            $response->handleError($e);
        }

        $this->renderView(
            "product-category/edit",
            [
                "response" => $response,
                "pageTitle" => "Edit Product Category"
            ]
        );
    }

}