<?php
namespace Polytropic\EcommBackend\controllers;

use Doctrine\DBAL\DriverManager;
use Exception;
use Polytropic\EcommBackend\helpers\FlashMessage;
use Polytropic\EcommBackend\helpers\Response;
use Polytropic\EcommBackend\models\AdminUser;

class UserController extends BaseController{

    private $conn;

    public function __construct()
    {
        $this->conn = DriverManager::getConnection(DATABASE_PARAMS);
    }

    public function manage(){
        $response = new Response();
        $users = [];

        try{
            $recordAction = $_POST["recordAction"] ?? false;
            if($recordAction != false){
                $recordId = $_POST["recordId"];
                $adminUser = AdminUser::findById($this->conn, $recordId);
                switch($recordAction){
                    case "deactiavteAccount": {
                        $adminUser->setIsAccountActive(false)->save($this->conn);
                        break;
                    }
                    case "activateAccount": {
                        $adminUser->setIsAccountActive(true)->save($this->conn);
                        break;
                    }
                    case "delete": {
                        $adminUser->delete($this->conn);
                        $response->success = true;
                        $response->successMessage = "Selected Record Deleted Successfully!";
                        break;
                    }
                }
            }
            $users = AdminUser::findAll($this->conn);
        }catch(Exception $e){
            $response->handleError($e);
        }

        $this->renderView("user/manage", [
            "response" => $response,
            "pageTitle" => "Manage Admin Users",
            "users" => $users
        ]);
    }

    public function add(){
        $response = new Response();

        if(isset($_REQUEST["formSubmitted"])){
            try{
                $firstName = trim($_POST["firstName"]);
                $lastName = trim($_POST["lastName"]);
                $emailAddress = trim($_POST["emailAddress"]);
                $password = $_POST["password"];
                $rePassword = $_POST["rePassword"];

                if(empty($firstName) || empty($lastName) || empty($emailAddress) || empty($password))
                    throw new Exception("All fields are mandatory.");
                if(!filter_var($emailAddress, FILTER_VALIDATE_EMAIL))
                    throw new Exception("Invalid email address.");
                if(strlen($password) < 10)
                    throw new Exception("Password must be at least 10 characters long.");
                if(strcmp($password, $rePassword) != 0)
                    throw new Exception("Password do not match.");
                if(AdminUser::checkEmailAddressExistence($this->conn, $emailAddress))
                    throw new Exception("Email address is already in use by another account. Please specify different email address.");
                
                $adminUser = new AdminUser();
                $adminUser->setFirstName($firstName)
                    ->setLastName($lastName)
                    ->setEmailAddress($emailAddress)
                    ->setPassword(sha1($password))
                    ->setIsSuperAdmin(false)
                    ->setIsAccountActive(true)
                    ->insert($this->conn);

                FlashMessage::setMessage("Admin User Added Successfully!");
                $this->redirectToRoute("admin/manage-users");
            }catch(Exception $e){
                $response->handleError($e);
            }
        }

        $this->renderView(
            "user/add",
            [
                "response" => $response,
                "pageTitle" => "Add Admin User"
            ]
        );
    }

    public function edit(){
        $response = new Response();
        $adminData = [];
        $recordId = null;

        try{
            if(isset($_POST["formSubmitted"])){
                $recordId = $_POST["recordId"];
                $adminData["firstName"] = trim($_POST["firstName"]);
                $adminData["lastName"] = trim($_POST["lastName"]);
                $adminData["emailAddress"] = trim($_POST["emailAddress"]);
                $adminData["password"] = $_POST["password"];
                $adminData["rePassword"] = $_POST["rePassword"];

                if(empty($adminData["firstName"]) || empty($adminData["lastName"]) || empty($adminData["emailAddress"]))
                    throw new Exception("Mandatory fields are found empty.");
                if(!filter_var($adminData["emailAddress"], FILTER_VALIDATE_EMAIL))
                    throw new Exception("Invalid email address.");
                if(!empty($adminData["password"]) and strlen($adminData["password"]) < 10)
                    throw new Exception("Password must be at least 10 characters long.");
                if(!empty($adminData["password"]) and strcmp($adminData["password"], $adminData["rePassword"]) != 0)
                    throw new Exception("Password do not match.");
                
                $adminUser = AdminUser::findById($this->conn, $recordId);
                $hasEmailAddressChanged = (strcasecmp($adminData["emailAddress"], $adminUser->getEmailAddress()) != 0);
                if($hasEmailAddressChanged){
                    if(AdminUser::checkEmailAddressExistence($this->conn, $adminData["emailAddress"]))
                        throw new Exception("An account with entered email address already exists.");
                }

                $adminUser->setFirstName($adminData["firstName"])
                    ->setLastName($adminData["lastName"])
                    ->setEmailAddress($adminData["emailAddress"])
                    ->save($this->conn);
                
                if(!empty($adminData["password"])){
                    $adminUser->setPassword(sha1($adminData["password"]))->save();
                }

                FlashMessage::setMessage("Record Updated Successfully!");
                $this->redirectToRoute("admin/manage-users");
            }else{
                $recordId = $_GET["id"];
                $adminUser = AdminUser::findById($this->conn, $_GET["id"]);
                $adminData = [
                    "firstName" => $adminUser->getFirstName(),
                    "lastName" => $adminUser->getLastName(),
                    "emailAddress" => $adminUser->getEmailAddress()
                ];
            }
        }catch(Exception $e){
            $response->handleError($e);
        }

        $this->renderView(
            "user/edit", 
            [
                "response" => $response,
                "pageTitle" => "Edit Admin User",
                "adminData" => $adminData,
                "recordId" => $recordId
            ]
        );
    }

}