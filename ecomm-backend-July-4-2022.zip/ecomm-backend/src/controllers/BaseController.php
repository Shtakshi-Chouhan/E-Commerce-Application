<?php
namespace Polytropic\EcommBackend\controllers;

use Exception;

abstract class BaseController{
   
    /**
     * @param string $viewFile
     * @param array $data
     * 
     * @return void
     */
    public function renderView(string $viewFile, $data = []): void{
        $viewFileFullPath = VIEW_FOLDER_PATH . $viewFile . ".phtml";
        if(!file_exists($viewFileFullPath))
            throw new Exception("View file not found.");
        require $viewFileFullPath;
    }

    public function redirectToRoute(string $route){
        header("Location: ".APP_BASE_URL."?route=".$route, true);
        exit(0);
    }

    public function redirect(string $url){
        header("Location: ".$url, true);
        exit(0);
    }

}