<?php
namespace Polytropic\EcommBackend\controllers;

use DateTime;
use Doctrine\DBAL\DriverManager;
use Polytropic\EcommBackend\helpers\Response;
use Exception;
use Polytropic\EcommBackend\models\AdminUser;

class MainController extends BaseController{

    private $conn;

    public function __construct(){
        $this->conn = DriverManager::getConnection(DATABASE_PARAMS);
    }

    public function login(){
        $response = new Response();

        if($_SESSION["isLoggedIn"] == true)
            $this->redirectToRoute("admin/dashboard");

        $formSubmitted = isset($_POST["formSubmitted"]);
        if($formSubmitted){
            try{
                $emailAddress = trim($_POST["emailAddress"]);
                $password = $_POST["password"];

                if(empty($emailAddress) || empty($password))
                    throw new Exception("All fields are mandatory.");
                
                $adminUser = AdminUser::findByEmailAddress($this->conn, $emailAddress);
                
                if(strcmp($adminUser->getPassword(), sha1($password)) != 0)
                    throw new Exception("Invalid account details.");

                if($adminUser->getIsAccountActive() == false)
                    throw new Exception("Your account has been disabled. Please contact site admin.");

                $adminUser->setLastLoggedIn((new DateTime()))->save($this->conn);

                $_SESSION["isLoggedIn"] = true;
                $_SESSION["userId"] = $adminUser->getId();
                $_SESSION["isSuperAdmin"] = $adminUser->getIsSuperAdmin();
                $_SESSION["currentUserName"] = $adminUser->getFirstName()." ".$adminUser->getLastName();
                
                $this->redirectToRoute("admin/dashboard");
            }catch(Exception $e){
                $response->handleError($e);
            }
        }

        $this->renderView("main/login", [
            "response" => $response,
            "pageTitle" => "Login Page",

        ]);  
    }

    public function logout(){
        unset($_SESSION["userId"]);
        unset($_SESSION["isSuperAdmin"]);
        $_SESSION["isLoggedIn"] = false;
        $this->redirectToRoute("admin/login");
    }

    public function dashboard(){
        $adminUser = AdminUser::findById($this->conn, $_SESSION["userId"]);

        $this->renderView("main/dashboard", [
            "firstName" => $adminUser->getFirstName(),
            "lastName" => $adminUser->getLastName(),
            "pageTitle" => "Dashboard"
        ]);
    }

    public function editProfile(){
        $response = new Response();
        $adminUser = AdminUser::findById($this->conn, $_SESSION["userId"]);
        $userProfile = ["emailAddress" => $adminUser->getEmailAddress()];

        if(isset($_POST["formSubmitted"])){
            try{
                $userProfile["firstName"] = trim($_POST["firstName"]);
                $userProfile["lastName"] = trim($_POST["lastName"]);
                if(empty($userProfile["firstName"]) || empty($userProfile["lastName"]))
                    throw new Exception("All fields are mandatory.");
                $adminUser
                    ->setFirstName($userProfile["firstName"])
                    ->setLastName($userProfile["lastName"])
                    ->save($this->conn);
                $response->success = true;
                $response->successMessage = "Profile Saved Successfully!";
            }catch(Exception $e){
                $response->handleError($e);
            }
        }else{
            $userProfile["firstName"] = $adminUser->getFirstName();
            $userProfile["lastName"] = $adminUser->getLastName();
        }

        $this->renderView("main/edit-profile", [
            "response" => $response,
            "userProfile" => $userProfile,
            "pageTitle" => "Edit Profile"
        ]);
    }

    public function changePassword(){
        $response = new Response();

        if(isset($_POST["formSubmitted"])){
            try{
                $currentPassword = $_POST["currentPassword"];
                $newPassword = $_POST["newPassword"];
                $rePassword = $_POST["rePassword"];

                $adminUser = AdminUser::findById($this->conn, $_SESSION["userId"]);
                if(strcmp($adminUser->getPassword(), sha1($currentPassword)) != 0)
                    throw new Exception("Current Password do not match.");
                if(strlen($newPassword) < 10)
                    throw new Exception("New password must not be less than 10 characters.");
                if(strcmp($newPassword, $rePassword) != 0)
                    throw new Exception("New password do not match.");
                
                $adminUser->setPassword(sha1($newPassword))->save($this->conn);
                
                $response->success = true;
                $response->successMessage = "Password Updated Successfully!";
            }catch(Exception $e){
                $response->handleError($e);
            }
        }

        $this->renderView("main/change-password", [
            "response" => $response,
            "pageTitle" => "Change Password"
        ]);
    }

}