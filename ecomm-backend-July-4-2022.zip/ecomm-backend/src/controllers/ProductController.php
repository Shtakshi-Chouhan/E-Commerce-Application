<?php
namespace Polytropic\EcommBackend\controllers;

use Doctrine\DBAL\DriverManager;
use Exception;
use Polytropic\EcommBackend\helpers\FlashMessage;
use Polytropic\EcommBackend\helpers\Response;
use Polytropic\EcommBackend\models\Product;
use Polytropic\EcommBackend\models\ProductCategory;
use Polytropic\EcommBackend\models\ProductImageGallery;

class ProductController extends BaseController{
    
    private $conn;

    public function __construct()
    {
        $this->conn = DriverManager::getConnection(DATABASE_PARAMS);
    }

    public function manage()
    {
        $response = new Response();
        $records = [];

        try{
            $recordAction = $_POST["recordAction"] ?? false;
            if($recordAction != false){
                $recordId = $_POST["recordId"];
                switch($recordAction){
                    case "showProduct": {
                        Product::findById($this->conn, $recordId)
                            ->setIsVisible(true)
                            ->save($this->conn);
                        break;
                    }
                    case "hideProduct": {
                        Product::findById($this->conn, $recordId)
                            ->setIsVisible(false)
                            ->save($this->conn);
                        break;
                    }
                    case "delete": {
                        Product::findById($this->conn, $recordId)
                            ->delete($this->conn);
                        break;
                    }
                    case "markOutOfStock": {
                        Product::findById($this->conn, $recordId)
                            ->setIsInStock(false)
                            ->save($this->conn);
                        break;
                    }
                    case "markInStock": {
                        Product::findById($this->conn, $recordId)
                            ->setIsInStock(true)
                            ->save($this->conn);
                        break;
                    }
                }
            }
            $response->categories = ProductCategory::getAll($this->conn);
            $response->currentPage = $_REQUEST["page"] ?? 1;
            $response->totalRecords = Product::getRecordCount($this->conn);
            $response->totalPages = Product::getTotalPages($this->conn);
            $response->categoryId = $_REQUEST["category_id"] ?? false;
            if(empty($response->categoryId)){
                $products = Product::getPage($this->conn, $response->currentPage);
            }else{
                $products = Product::getPageByCategory($this->conn, $response->categoryId, $response->currentPage);
            }
            foreach($products as $product){
                $records[] = [
                    "productId" => $product->getId(),
                    "category" => ProductCategory::findById($this->conn, $product->getCategoryId()),
                    "title" => $product->getTitle(),
                    "description" => $product->getDescription(),
                    "sellingPrice" => $product->getSellingPrice(),
                    "isInStock" => $product->getIsInStock(),
                    "isVisible" => $product->getIsVisible(),
                    "featuredImage" => $product->getFeaturedImage()
                ];
            }
        }catch(Exception $e){
            $response->handleError($e);
        }

        $this->renderView(
            "product/manage", [
                "response" => $response,
                "pageTitle" => "Manage Product",
                "records" => $records
            ]
        );
    }

    public function add()
    {
        $response = new Response();

        try{
            $response->categories = ProductCategory::getAll($this->conn);
            if(isset($_POST["formSubmitted"])){
                $category = $_POST["category"];
                $title = trim($_POST["title"]);
                $description = trim($_POST["description"]);
                $sellingPrice = $_POST["sellingPrice"];
                $isInStock = ($_POST["isInStock"] == "yes");
                $isVisible = ($_POST["isVisible"] == "yes");
                $featuredImage = $_FILES["featuredImage"] ?? false;

                if(empty($category) || empty($title) || empty($sellingPrice) || empty($featuredImage))
                    throw new Exception("Mandatory fields found empty.");
                if(!is_numeric($sellingPrice) || $sellingPrice < 0)
                    throw new Exception("Selling price must be numeric and must not be less than 0.");
                if($featuredImage["error"] != UPLOAD_ERR_OK)
                    throw new Exception("Featured image failed to upload.");

                //saving featured Image
                $fileExtension = strtolower(pathinfo($featuredImage["name"], PATHINFO_EXTENSION));
                if(!in_array($fileExtension, ["jpg", "jpeg", "png", "gif"]))
                    throw new Exception("Faetured image file must be one with following extensions - jpg, jpeg, png or, gif.");
                if($featuredImage["size"] > (500 * 1024))
                    throw new Exception("Featured image file cannot exceeds limit of 500KB");
                $fileName = uniqid("product-") . "." . $fileExtension;
                $filePath = UPLOAD_FOLDER . $fileName;
                if(!move_uploaded_file($featuredImage["tmp_name"], $filePath))
                    throw new Exception("Failed to save featured image. Please re-try again.");
                
                (new Product())
                    ->setCategoryId($category)
                    ->setTtile($title)
                    ->setDescription($description)
                    ->setSellingPrice(floatval($sellingPrice))
                    ->setIsInStock($isInStock)
                    ->setIsVisible($isVisible)
                    ->setfeaturedImage($fileName)
                    ->insert($this->conn);                    
                FlashMessage::setMessage("Product Added Successfully.");
                $this->redirectToRoute("admin/product/manage");
            }
        }catch(Exception $e){
            $response->handleError($e);
        }

        $this->renderView(
            "product/add",
            [
                "response" => $response,
                "pageTitle" => "Add New Product"
            ]
        );
    }

    public function edit()
    {

    }

    public function manageGallery(){
        $response = new Response();
        $response->addImagesError = false;

        try{
            $productId = $_REQUEST["productId"];
            $response->product = Product::findById($this->conn, $productId);
            $response->images = ProductImageGallery::findByProductId($this->conn, $productId);
            if(isset($_POST["formSubmitted"])){
                switch($_POST["recordAction"]){
                    case "addImages": {
                        $transactionStarted = false;
                        try{
                            $rawImageFiles = $_FILES["images"];
                            $response->uploadedImagesCount = count($rawImageFiles["name"]);
                            $imageFiles = [];
                            for($counter = 0; $counter < $response->uploadedImagesCount; $counter++){
                                $imageFiles[] = [
                                    "name" => $rawImageFiles["name"][$counter],
                                    "error" => $rawImageFiles["error"][$counter],
                                    "size" => $rawImageFiles["size"][$counter],
                                    "tmp_name" => $rawImageFiles["tmp_name"][$counter],
                                    "type" => $rawImageFiles["type"][$counter]
                                ];
                            }
                            $uploadImageFileNames = [];
                            foreach($imageFiles as $fileIndex => $imageFile){
                                if($imageFile["error"] != UPLOAD_ERR_OK)
                                    throw new Exception("File #".($fileIndex + 1)." failed to upload.");
                                $extension = strtolower(pathinfo($imageFile["name"], PATHINFO_EXTENSION));
                                if(!in_array($extension, ['jpg', 'jpeg', 'png', 'gif']))
                                    throw new Exception("File #".($fileIndex + 1)." must be one with following extension - jpg, jpeg, png or, gif");
                                if($imageFile["size"] >= (500 * 1024))
                                    throw new Exception("File #".($fileIndex + 1)." must not exceed 500KB size limit.");
                                $fileName = uniqid("product-") . "." . $extension;
                                $filePath = UPLOAD_FOLDER . $fileName;
                                if(!move_uploaded_file($imageFile["tmp_name"], $filePath))
                                    throw new Exception("Failed to save File #".($fileIndex + 1));
                                $uploadImageFileNames[] = $fileName;
                            }
                            $this->conn->beginTransaction();
                            $transactionStarted = true;
                            foreach($uploadImageFileNames as $imageGalleryFile){
                                $record = new ProductImageGallery();
                                $record->setProductId($productId)
                                    ->setImage($imageGalleryFile)
                                    ->setIsVisible(true)
                                    ->insert($this->conn);
                            }
                            $this->conn->commit();
                            FlashMessage::setMessage("Images Uploaded Successfully!");
                        }catch(Exception $e){
                            if($transactionStarted) $this->conn->rollBack();
                            $response->addImagesError = true;
                            throw $e;
                        }
                        break;
                    }
                    case "show": {
                        $recordId = $_POST["recordId"];
                        ProductImageGallery::findById($this->conn, $recordId)->setIsVisible(true)->save($this->conn);
                        break;
                    }
                    case "hide": {
                        $recordId = $_POST["recordId"];
                        ProductImageGallery::findById($this->conn, $recordId)->setIsVisible(false)->save($this->conn);
                        break;
                    }
                    case "delete": {
                        $recordId = $_POST["recordId"];
                        ProductImageGallery::findById($this->conn, $recordId)->delete($this->conn);
                        break;
                    }
                }
                $response->images = ProductImageGallery::findByProductId($this->conn, $productId);
            }
        }catch(Exception $e){
            $response->handleError($e);
        }

        $this->renderView(
            "product/manage-gallery",
            [
                "response" => $response,
                "pageTitle" => "Manage Product Image Gallery"
            ]
        );
    }

}