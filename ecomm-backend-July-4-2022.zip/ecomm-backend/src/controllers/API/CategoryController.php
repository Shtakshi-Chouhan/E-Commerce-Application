<?php
namespace Polytropic\EcommBackend\controllers\API;

use Doctrine\DBAL\DriverManager;
use Exception;
use Polytropic\EcommBackend\helpers\JSONResponse;
use Polytropic\EcommBackend\models\Product;
use Polytropic\EcommBackend\models\ProductCategory;

class CategoryController {

    private $conn;

    public function __construct(){
        $this->conn = DriverManager::getConnection(DATABASE_PARAMS);
    }

    public function get(array $params)
    {
        $response = new JSONResponse();
        try{
            switch($params["action"]){
                case "topLevelCategory": {
                    $categories = ProductCategory::getTopLevelCategory($this->conn);
                    $output = [];
                    foreach($categories as $cat){
                        $output[] = (object)[
                            "id" => $cat->getId(),
                            "title" => $cat->getTitle(), 
                            "description" => $cat->getDescription(),
                            "bannerImage" => APP_BASE_URL . "/uploads/" . $cat->getBannerImage(),
                            "hasChildren" => boolval(count(ProductCategory::getChildrenCategory($this->conn, $cat->getId())))
                        ];
                    }
                    $response->results = $output;
                    break;
                }
                case "children": {
                    $categoryId = $params["id"];
                    $children = ProductCategory::getChildrenCategory($this->conn, $categoryId);
                    $response->results = [];
                    foreach($children as $cat){
                        $response->results[] = (object)[
                            "id" => $cat->getId(),
                            "title" => $cat->getTitle(), 
                            "description" => $cat->getDescription(),
                            "bannerImage" => APP_BASE_URL . "/uploads/" . $cat->getBannerImage(),
                            "hasChildren" => boolval(count(ProductCategory::getChildrenCategory($this->conn, $cat->getId())))
                        ];
                    }
                    break;
                }
                case "detail": {
                    $categoryId = $params["id"];
                    $category = ProductCategory::findById($this->conn, $categoryId);
                    $children = ProductCategory::getChildrenCategory($this->conn, $categoryId);
                    $categoryChildrern = [];
                    foreach($children as $cat){
                        $categoryChildrern[] = (object)[
                            "id" => $cat->getId(),
                            "title" => $cat->getTitle(), 
                            "description" => $cat->getDescription(),
                            "bannerImage" => APP_BASE_URL . "/uploads/" . $cat->getBannerImage(),
                            "hasChildren" => boolval(count(ProductCategory::getChildrenCategory($this->conn, $cat->getId())))
                        ];
                    }
                    $response->result = (object)[
                        "id" => $category->getId(),
                        "title" => $category->getTitle(),
                        "description" => $category->getDescription(),
                        "bannerImage" => APP_BASE_URL . "/uploads/" . $category->getBannerImage(),
                        "children" => $categoryChildrern
                    ];
                    break;
                }
            }
            $response->setSuccess(true);
        }catch(Exception $e){
            $response->handleError($e);
        }

        return $response->sendResponse();
    }

    public function getProducts(array $params)
    {
        $response = new JSONResponse();

        try{
            $categoryId = $params["catId"];
            $products =  Product::getAllByCategory($this->conn, $categoryId);
            /** @var \Polytropic\EcommBackend\models\Product $product */
            foreach($products as $product){
                if(!$product->getIsVisible()) continue;
                $response->result[] = (object)[
                    "id" => $product->getId(),
                    "title" => $product->getTitle(),
                    "sellingPrice" => number_format($product->getSellingPrice(), "2"),
                    "isInStock" => $product->getIsInStock(),
                    "featuredImage" => APP_BASE_URL . "/uploads/" . $product->getFeaturedImage()
                ];
            }
            $response->setSuccess(true);
        }catch(Exception $e){
            $response->handleError($e);
        }

        return $response->sendResponse();
    }

}