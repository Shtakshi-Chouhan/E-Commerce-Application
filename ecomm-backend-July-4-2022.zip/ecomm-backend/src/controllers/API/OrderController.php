<?php
namespace Polytropic\EcommBackend\controllers\API;

use Doctrine\DBAL\DriverManager;

class OrderController {

    private $conn;

    public function __construct(){
        $this->conn = DriverManager::getConnection(DATABASE_PARAMS);
    }

    

}