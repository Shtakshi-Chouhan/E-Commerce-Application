<?php
namespace Polytropic\EcommBackend\controllers\API;

use DateTime;
use DateTimeZone;
use Doctrine\DBAL\DriverManager;
use Exception;
use Polytropic\EcommBackend\helpers\JSONResponse;
use Polytropic\EcommBackend\models\AppUserLogin;
use Polytropic\EcommBackend\models\AppUserToken;
use Polytropic\EcommBackend\models\Customer;

class MainController {

    private $conn;

    public function __construct(){
        $this->conn = DriverManager::getConnection(DATABASE_PARAMS);
    }

    public function login(array $params)
    {
        $response = new JSONResponse();
        
        try{
            $emailAddress = $_POST["emailAddress"] ?? false;
            $password = $_POST["password"] ?? false;

            if(empty($emailAddress) || empty($password))
                throw new Exception("Mandatory fields are found empty.");
            //finding customer account by email address
            $customer = Customer::getByEmailAddress($this->conn, $emailAddress);
            if(!$customer)
                throw new Exception("Invalid login details.");
            if(!$customer->getAccountEnabled())
                throw new Exception("Your account has been disabled. Contact site admin.");
            //finding app user login record against customer id
            $appUserLoginRecord = AppUserLogin::findByCustomerId($this->conn, $customer->getId());
            if(!$appUserLoginRecord)
                throw new Exception("Invalid login details.");
            if(strcmp(sha1($password), $appUserLoginRecord->getAccountPassword()) != 0)
                throw new Exception("Invalid login details.");
            //generating token and sending back
            $sessionToken = sha1(time() . microtime() . $customer->getId());
            $issueDate = new DateTime();
            $expiryDate = (new DateTime())->setTimestamp($issueDate->getTimestamp() + (30 * 24 * 60 * 60));
            $tokenRecord = new AppUserToken();
            $tokenRecord->setCustomerId($customer->getId())
                ->setToken($sessionToken)
                ->setTokenIssueDate($issueDate)
                ->setTokenExpiryDate($expiryDate);
            $tokenRecord->insert($this->conn);
            $appUserLoginRecord->setLastLoginOn(new DateTime())->save($this->conn);
            $response->token = $sessionToken;
            $response->customer = (object)[
                "firstName" => $customer->getFirstName(),
                "lastName" => $customer->getLastName(),
                "emailAddress" => $customer->getEmailAddress(),
                "mobileNumber" => $customer->getMobileNumber()
            ];
            $response->setSuccess(true);
        }catch(Exception $e){
            $response->handleError($e);
        }

        return $response->sendResponse();
    }

    public function logout(array $params)
    {
        $response = new JSONResponse();

        try{
            $token = $params["token"] ?? false;
            if($token !== false){
                AppUserToken::findByToken($this->conn, $token)->delete($this->conn);
            }
            $response->setSuccess(true);
        }catch(Exception $e){
            $response->sendResponse();
        }

        return $response->sendResponse();
    }

    

}