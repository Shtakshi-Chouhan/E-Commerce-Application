<?php
namespace Polytropic\EcommBackend\controllers\API;

use Doctrine\DBAL\DriverManager;
use Exception;
use Polytropic\EcommBackend\helpers\JSONResponse;
use Polytropic\EcommBackend\models\Product;
use Polytropic\EcommBackend\models\ProductImageGallery;

class ProductController {

    private $conn;

    public function __construct(){
        $this->conn = DriverManager::getConnection(DATABASE_PARAMS);
    }

    public function get(array $params)
    {
        $response = new JSONResponse();

        try{
            $ids = $params["id"];
            $products = explode(",", $ids);
            $response->results = [];
            foreach($products as $productId){
                $product = Product::findById($this->conn, $productId);
                $galleryImages = ProductImageGallery::findByProductId($this->conn, $productId);
                $images = [];
                foreach($galleryImages as $galleryImage){
                    if(!$galleryImage->getIsVisible()) continue;
                    $images[] = APP_BASE_URL . "/uploads/" . $galleryImage->getImage();
                }
                $response->results[] = (object)[
                    "id" => $product->getId(),
                    "title" => $product->getTitle(),
                    "description" => $product->getDescription(),
                    "sellingPrice" => number_format($product->getSellingPrice(), 2),
                    "priceAsNumber" => $product->getSellingPrice(),
                    "inStock" => $product->getIsInStock(),
                    "images" => $images,
                    "featuredImage" => APP_BASE_URL . "/uploads/" . $product->getFeaturedImage()
                ];
            }
            $response->setSuccess(true);
        }catch(Exception $e){
            $response->handleError($e);
        }

        return $response->sendResponse();
    }

}