<?php
namespace Polytropic\EcommBackend\controllers\API;

use DateTime;
use Doctrine\DBAL\DriverManager;
use Exception;
use Polytropic\EcommBackend\helpers\JSONResponse;
use Polytropic\EcommBackend\models\AppUserLogin;
use Polytropic\EcommBackend\models\Customer;

class CustomerController {

    private $conn;

    public function __construct(){
        $this->conn = DriverManager::getConnection(DATABASE_PARAMS);
    }

    public function get(array $params)
    {
        $response = new JSONResponse();

        try{
            $customerId = $params["customerId"] ?? false;
            if($customerId === false)
                throw new Exception("Invalid request.");
            $customer = Customer::findById($this->conn, $customerId);
            $response->result = (object)[
                "firstName" => $customer->getFirstName(),
                "lastName" => $customer->getLastName(),
                "emailAddress" => $customer->getEmailAddress(),
                "mobileNumber" => $customer->getMobileNumber(),
                "alternateMobileNumber" => $customer->getAltMobileNumber(),
                "registeredOn" => $customer->getRegisteredOn()->format("d/M/Y")
            ];
            $response->setSuccess(true);
        }catch(Exception $e){
            $response->handleError($e);
        }

        return $response->sendResponse();
    }

    public function add(){
        $response = new JSONResponse();

        try{
            //parsing the raw post data
            $rawPostData = file_get_contents("php://input");
            $customer = json_decode($rawPostData);
            if(is_null($customer))
                throw new Exception("Invalid customer data submitted.");

            $firstName = trim($customer->firstName);
            $lastName = trim($customer->lastName);
            $emailAddress = trim($customer->emailAddress);
            $mobileNumber = trim($customer->mobileNumber);
            $password = $customer->password;
            $confirmPassword = $customer->confirmPassword;

            if( empty($firstName) || empty($lastName) || empty($emailAddress) || empty($mobileNumber) || empty($password)){
                throw new Exception("All fields are mandatory.");
            }elseif(!filter_var($emailAddress, FILTER_VALIDATE_EMAIL)){
                throw new Exception("Invalid email address.");
            }elseif(!preg_match("#^\d{10}$#", $mobileNumber)){
                throw new Exception("Invalid mobile number, must be numeric 10 digits number.");
            }elseif(strlen($password) < 10){
                throw new Exception("Password must be at least 10 characters long.");
            }elseif(strcmp($password, $confirmPassword) != 0){
                throw new Exception("Password do not match.");
            }

            //checking if an account already exists with specified email address
            $customers = Customer::searchByEmailAddress($this->conn, $emailAddress);
            if(count($customers) > 0){
                throw new Exception("A customer account already exists with specified email address.");
            }

            //adding new customer
            $record = new Customer();
            $record->setFirstName($firstName)
                ->setLastName($lastName)
                ->setEmailAddress($emailAddress)
                ->setMobileNumber($mobileNumber)
                ->setRegisteredOn(new DateTime())
                ->setAccountEnabled(true)
                ->setAccountVerified(true);
            $record->insert($this->conn);
            //adding login details for the added customer account
            $appUserLogin = new AppUserLogin();
            $appUserLogin->setCustomerId($record->getId())
                ->setAccountPassword(sha1($password))
                ->insert($this->conn);
            $response->setSuccess(true);
        }catch(Exception $e){
            $response->handleError($e);
        }

        return $response->sendResponse();
    }

    public function update(array $params)
    {
        $response = new JSONResponse();
        
        try{
            $customerId = $params["customerId"];
            //parsing raw post data
            $rawPostData = file_get_contents("php://input");
            $customer = json_decode($rawPostData);
            if(!$customer)
                throw new Exception("Invalid customer data submitted.");

            $firstName = trim($customer->firstName);
            $lastName = trim($customer->lastName);
            $mobileNumber = trim($customer->mobileNumber);
            $alternateMobileNumber = is_null($customer->alternateMobileNumber) ? false : trim($customer->alternateMobileNumber);
            $currentPassword = $customer->currentPassword ?? false;
            $password = $customer->password ?? false;
            $confirmPassword = $customer->confirmPassword ?? false;

            $appUserLogin = AppUserLogin::findByCustomerId($this->conn, $customerId);
            
            if(empty($firstName) || empty($lastName) || empty($mobileNumber))
                throw new Exception("Mandatory fields are found empty.");
            if(!preg_match("#^\d{10}$#", $mobileNumber))
                throw new Exception("Invalid mobile number, must be 10 digits number.");
            if(!empty($alternateMobileNumber) and !preg_match("#^\d{10}$#", $mobileNumber))
                throw new Exception("Alternate Mobile Number must be 10 digits number.");
            if($mobileNumber == $alternateMobileNumber)
                throw new Exception("Alternate Mobile Number cannot be same as Mobile Number");
            if(!empty($currentPassword) and strcmp($appUserLogin->getAccountPassword(), sha1($currentPassword)) != 0)
                throw new Exception("Current Password do not match.");
            if(!empty($currentPassword) and !empty($password) and strlen($password) < 10)
                throw new Exception("Password must be at least 10 characters long");
            if(!empty($currentPassword) and !empty($password) and strcmp($password, $confirmPassword) != 0)
                throw new Exception("New password do not match");

            $customerRecord = Customer::findById($this->conn, $customerId);
            $customerRecord->setFirstName($firstName)->setLastName($lastName)->setMobileNumber($mobileNumber);
            if(!empty($alternateMobileNumber))
                $customerRecord->setAltMobileNumber($alternateMobileNumber);
            $customerRecord->save($this->conn);

            if(!empty($currentPassword) and !empty($password)){
                $appUserLogin->setAccountPassword(sha1($password))->save($this->conn);
            }

            $response->setSuccess(true);
        }catch(Exception $e){
            $response->handleError($e);
        }

        return $response->sendResponse();
    }

}