<?php
namespace Polytropic\EcommBackend\controllers;

use Doctrine\DBAL\DriverManager;
use Exception;
use Polytropic\EcommBackend\helpers\Response;
use Polytropic\EcommBackend\models\Customer;
use Polytropic\EcommBackend\models\CustomerBillingAddress;
use Polytropic\EcommBackend\models\CustomerShippingAddress;

class CustomerController extends BaseController{

    private $conn;

    public function __construct()
    {
        $this->conn = DriverManager::getConnection(DATABASE_PARAMS);
    }

    public function manage()
    {
        $response = new Response();

        try{
            if(isset($_POST["recordAction"])){
                $recordId = $_POST["recordId"];
                switch($_POST["recordAction"]){
                    case "enable": {
                        Customer::findById($this->conn, $recordId)->setAccountEnabled(true)->save($this->conn);
                        break;
                    }
                    case "disable": {
                        Customer::findById($this->conn, $recordId)->setAccountEnabled(false)->save($this->conn);
                        break;
                    }
                }
            }
            if(isset($_POST["searchBy"])){
                $searchBy = $_POST["searchBy"];
                $searchText = $_POST["searchText"];
                $response->currentPage = 1;
                $response->totalPages = 1;
                switch($searchBy){
                    case "firstName": {
                        $response->records = Customer::searchByFirstName($this->conn, $searchText);
                        break;
                    }
                    case "emailAddress": {
                        $response->records = Customer::searchByEmailAddress($this->conn, $searchText);
                        break;
                    }
                    case "mobileNumber": {
                        $response->records = Customer::searchByMobileNumber($this->conn, $searchText);
                        break;
                    }
                }
                $response->totalRecords = count($response->records);
            }else{
                $response->currentPage = $_REQUEST["page"] ?? 1;
                $response->totalRecords = Customer::getRecordCount($this->conn);
                $response->totalPages = Customer::getTotalPages($this->conn);
                $response->records = Customer::getPage($this->conn, $response->currentPage);
            }
        }catch(Exception $e){
            $response->handleError($e);
        }

        $this->renderView(
            "customer/manage",
            [
                "response" => $response,
                "pageTitle" => "Manage Customers"
            ]
        );
    }

    public function view()
    {
        $response = new Response();
        try{
            $customerId = $_GET["id"];
            $response->customer = Customer::findById($this->conn, $customerId);
            $response->billing = CustomerBillingAddress::findByCustomerId($this->conn, $customerId);
            $response->shippingAddresses = CustomerShippingAddress::findByCustomerId($this->conn, $customerId);
        }catch(Exception $e){
            $response->handleError($e);
        }

        $this->renderView(
            "customer/view",
            [
                "response" => $response,
                "pageTitle" => "Customer Details"
            ]
        );
    }

}