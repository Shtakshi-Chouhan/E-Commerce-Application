<?php
namespace Polytropic\EcommBackend\controllers;

use Doctrine\DBAL\DriverManager;
use Exception;
use Polytropic\EcommBackend\helpers\FlashMessage;
use Polytropic\EcommBackend\helpers\Response;
use Polytropic\EcommBackend\models\Customer;
use Polytropic\EcommBackend\models\CustomerBillingAddress;
use Polytropic\EcommBackend\models\CustomerOrder;
use Polytropic\EcommBackend\models\CustomerOrderItem;
use Polytropic\EcommBackend\models\CustomerShippingAddress;
use stdClass;

class CustomerOrderController extends BaseController{

    private $conn;

    public function __construct()
    {
        $this->conn = DriverManager::getConnection(DATABASE_PARAMS);
    }

    public function manage()
    {
        $response = new Response();

        try{
            if(isset($_POST["formSubmitted"])){
                $recordId = $_POST["recordId"];
                switch($_POST["recordAction"]){
                    case "changeStatus": {
                        CustomerOrder::findById($this->conn, $recordId)->setStatus($_POST["status"])->save($this->conn);
                        FlashMessage::setMessage("Order status updated successfully.");
                        break;
                    }
                }
            }
            $response->totalRecords = CustomerOrder::getRecordCount($this->conn);
            $response->totalPages = CustomerOrder::getTotalPages($this->conn);
            $response->currentPage = $_REQUEST["page"] ?? 1;
            $response->records = CustomerOrder::getPage($this->conn, $response->currentPage);
        }catch(Exception $e){
            $response->handleError($e);
        }

        $this->renderView(
            "orders/manage",
            [
                "response" => $response,
                "pageTitle" => "Manage Orders",
                "conn" => $this->conn
            ]
        );
    }

    public function view()
    {
        $response = new Response();

        try{
            $orderId = $_GET["id"];
            $response->order = CustomerOrder::findById($this->conn, $orderId);
            $response->customer = Customer::findById($this->conn, $response->order->getCustomerId());
            $response->billing = CustomerBillingAddress::findById($this->conn, $response->order->getCustomerBillingAddressId());
            $response->shipping = CustomerShippingAddress::findById($this->conn, $response->order->getCustomerShippingAddressId());
            $response->details = CustomerOrderItem::findByOrderId($this->conn, $orderId);
        }catch(Exception $e){
            $response->handleError($e);
        }

        $this->renderView(
            "orders/view",
            [
                "response" => $response,
                "pageTitle" => "View Order",
                "conn" => $this->conn
            ]
        );
    }

}