<?php
namespace Polytropic\EcommBackend\APIException;

use Exception;

class HTTPUnauthorizedException extends Exception {}