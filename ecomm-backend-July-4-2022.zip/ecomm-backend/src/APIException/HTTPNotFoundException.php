<?php
namespace Polytropic\EcommBackend\APIException;

use Exception;

class HTTPNotFoundException extends Exception {}