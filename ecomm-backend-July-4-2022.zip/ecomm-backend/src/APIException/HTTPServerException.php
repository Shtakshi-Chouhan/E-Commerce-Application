<?php
namespace Polytropic\EcommBackend\APIException;

use Exception;

class HTTPServerException extends Exception {}