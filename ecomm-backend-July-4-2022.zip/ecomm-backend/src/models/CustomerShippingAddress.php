<?php
namespace Polytropic\EcommBackend\models;

use Doctrine\DBAL\Connection;
use Exception;

class CustomerShippingAddress implements ModelInterface{
    
    private int $id;
    private int $customerId;
    private string $title;
    private string $name;
    private string $addressLine1;
    private ?string $addressLine2 = null;
    private string $landmark;
    private string $city;
    private string $state;
    private string $country;
    private ?string $pincode = null;   
    
    /**
     * Get the value of id
     */ 
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId(int $id): CustomerShippingAddress
    {
        $this->id = $id;
        return $this;
    }
    /**
     * Get the value of customerId
     */ 
    public function getCustomerId(): int
    {
        return $this->customerId;
    }

    /**
     * Set the value of customerId
     *
     * @return  self
     */ 
    public function setCustomerId(int $customerId): CustomerShippingAddress
    {
        $this->customerId = $customerId;
        return $this;
    }
    
    /**
     * Get the value of title
     */ 
    public function getTitle(): string
    {
        return $this->title;
    }

    /**
     * Set the value of titke
     *
     * @return  self
     */ 
    public function setTitle(string $title): CustomerShippingAddress
    {
        $this->title = $title;
        return $this;
    }

    
    /**
     * Get the value of name
     */ 
    public function getName(): string
    {
        return $this->name;
    }

    /**
     * Set the value of name
     *
     * @return  self
     */ 
    public function setName($name): CustomerShippingAddress
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get the value of addressLine1
     */ 
    public function getAddressLine1(): string
    {
        return $this->addressLine1;
    }

    /**
     * Set the value of addressLine1
     *
     * @return  self
     */ 
    public function setAddressLine1(string $addressLine1): CustomerShippingAddress
    {
        $this->addressLine1 = $addressLine1;
        return $this;
    }

    /**
     * Get the value of addressLine2
     */ 
    public function getAddressLine2(): ?string
    {
        return $this->addressLine2;
    }

    /**
     * Set the value of addressLine2
     *
     * @return  self
     */ 
    public function setAddressLine2(?string $addressLine2): CustomerShippingAddress
    {
        $this->addressLine2 = $addressLine2;
        return $this;
    }
    
    /**
     * Get the value of landmark
     */ 
    public function getLandmark(): string
    {
        return $this->landmark;
    }

    /**
     * Set the value of landmark
     *
     * @return  self
     */ 
    public function setLandmark(string $landmark)
    {
        $this->landmark = $landmark;

        return $this;
    }
    
    
    /**
     * Get the value of city
     */ 
    public function getCity(): string
    {
        return $this->city;
    }

    /**
     * Set the value of city
     *
     * @return  self
     */ 
    public function setCity(string $city): CustomerShippingAddress
    {
        $this->city = $city;

        return $this;
    }

    /**
     * Get the value of state
     */ 
    public function getState(): string
    {
        return $this->state;
    }

    /**
     * Set the value of state
     *
     * @return  self
     */ 
    public function setState(string $state): CustomerShippingAddress
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get the value of country
     */ 
    public function getCountry(): string
    {
        return $this->country;
    }

    /**
     * Set the value of country
     *
     * @return  self
     */ 
    public function setCountry(string $country): CustomerShippingAddress
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get the value of pincode
     */ 
    public function getPincode(): ?string
    {
        return $this->pincode;
    }

    /**
     * Set the value of pincode
     *
     * @return  self
     */ 
    public function setPincode(?string $pincode): CustomerShippingAddress
    {
        $this->pincode = $pincode;
        return $this;
    }

    public function insert(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->insert("customer_shipping_address")
                ->values([
                    "customer_id" => "?",
                    "title" => "?",
                    "name" => "?",
                    "address_line1" => "?",
                    "address_line2" => "?",
                    "landmark" => "?",
                    "city" => "?",
                    "state" => "?",
                    "country" => "?",
                    "pincode" => "?"
                ])->setParameters([
                    $this->customerId,
                    $this->title,
                    $this->name,
                    $this->addressLine1,
                    $this->addressLine2,
                    $this->landmark,
                    $this->city,
                    $this->state,
                    $this->country,
                    $this->pincode
                ])->executeStatement();
            $this->id = $conn->lastInsertId();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function save(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->update("customer_shipping_address")
                ->set("customer_id", "?")
                ->set("title", "?")
                ->set("name", "?")
                ->set("address_line1", "?")
                ->set("address_line2", "?")
                ->set("landmark", "?")
                ->set("city", "?")
                ->set("state", "?")
                ->set("country", "?")
                ->set("pincode", "?")
                ->where("id = ?")
                ->setParameters([
                    $this->customerId,
                    $this->title,
                    $this->name,
                    $this->addressLine1,
                    $this->addressLine2,
                    $this->landmark,
                    $this->city,
                    $this->state,
                    $this->country,
                    $this->pincode,
                    $this->id
                ])->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function delete(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->delete("customer_shipping_address")
                ->where("id = ?")
                ->setParameter(0, $this->id)
                ->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public static function getObject(array $record): CustomerShippingAddress
    {
        return (new CustomerShippingAddress())
            ->setId($record["id"])
            ->setTitle($record["title"])
            ->setName($record["name"])
            ->setAddressLine1($record["address_line1"])
            ->setAddressLine2($record["address_line2"])
            ->setLandmark($record["landmark"])
            ->setCity($record["city"])
            ->setState($record["state"])
            ->setCountry($record["country"])
            ->setPincode($record["pincode"]);
    }

    public static function findById(Connection $conn, int $id): ?CustomerShippingAddress
    {
        try{
            $record = $conn->createQueryBuilder()
                ->select("*")
                ->from("customer_shipping_address")
                ->where("id = ?")
                ->setParameter(0, $id)
                ->executeQuery()
                ->fetchAssociative();
            if(!$record) return null;
            return self::getObject($record);
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public static function findByCustomerId(Connection $conn, int $customerId): array
    {
        $addresses = [];

        try{
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("customer_shipping_address")
                ->where("customer_id = ?")
                ->setParameter(0, $customerId)
                ->executeQuery()
                ->fetchAllAssociative();
            foreach($records as $record){
                $addresses[] = self::getObject($record);
            }
            return $addresses;
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }

        return $addresses;
    }

}