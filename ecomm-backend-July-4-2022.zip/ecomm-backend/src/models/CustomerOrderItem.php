<?php
namespace Polytropic\EcommBackend\models;

use Doctrine\DBAL\connection;
use Exception;

class CustomerOrderItem implements ModelInterface{

    private int $id;
    private int $OrderId;
    private int $productId;
    private float $SellingPrice;
    private int $quantity;

    /**
     * Get the value of id
     */ 
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId(int $value): CustomerOrderItem
    {
        $this->id = $value;

        return $this;
    }

    /**
     * Get the value of OrderId
     */ 
    public function getOrderId(): int
    {
        return $this->OrderId;
    }

    /**
     * Set the value of OrderId
     *
     * @return  self
     */ 
    public function setOrderId(int $value): CustomerOrderItem
    {
        $this->OrderId = $value;

        return $this;
    }

    /**
     * Get the value of productId
     */ 
    public function getProductId(): int
    {
        return $this->productId;
    }

    /**
     * Set the value of productId
     *
     * @return  self
     */ 
    public function setProductId(int $value): CustomerOrderItem
    {
        $this->productId = $value;
        return $this;
    }

    /**
     * Get the value of SellingPrice
     */ 
    public function getSellingPrice(): float
    {
        return $this->SellingPrice;
    }

    /**
     * Set the value of SellingPrice
     *
     * @return  self
     */ 
    public function setSellingPrice(float $value): CustomerOrderItem
    {
        $this->SellingPrice = $value;

        return $this;
    }

    /**
     * Get the value of quantity
     */ 
    public function getQuantity(): int
    {
        return $this->quantity;
    }

    /**
     * Set the value of quantity
     *
     * @return  self
     */ 
    public function setQuantity(int $value): CustomerOrderItem
    {
        $this->quantity = $value;
        return $this;
    }

    public function insert(connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                 ->insert("customer_order_details")
                 ->values([
                     "order_id" => "?",
                     "product_id" => "?",
                     "selling_price" => "?",
                     "qty" => "?"
                 ])->setParameters([
                    $this->orderId,
                    $this->productId,
                    $this->sellingPrice,
                    $this->quantity, 
                 ])->executeStatement();
            $this->id = $conn->lastInsertId();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function save(connection $conn)
    {
        try{
            $conn->CreateQueryBuilder()
            ->update("customer_order_details")
            ->set("order_id", "?")
            ->set("product_id", "?")
            ->set("selling_price", "?")
            ->set("qty", "?")
            ->where("id = ?")
            ->setParameters([
                $this->orderId,
                $this->productId,
                $this->sellingPrice,
                $this->quantity,
                $this->id
            ])->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }
    public function delete(connection $conn)
    {
        try{
            $conn->CreateQuerybuilder()
            ->delete("customer_order_details")
            ->where("id = ?")
            ->setParameter(0, $this->id)
            ->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public static function getobject(array $record): CustomerOrderItem{
        $customerOrderItem = new CustomerOrderItem();
        $customerOrderItem->setId($record["id"])
         ->setOrderId($record["order_id"])
         ->setProductId($record["product_id"])
         ->setSellingPrice($record["selling_price"])
         ->setQuantity($record["qty"]);
        return $customerOrderItem;
    }

    public static function findById(Connection $conn, int $id): CustomerOrderItem{
        try{
            $record = $conn->createQueryBuilder()
              ->select("*")
              ->from("customer_order_details")
              ->where("id = ?")
              ->setParameter(0, $id)
              ->executeQuery()
              ->fetchAssociative();
            return self::getObject($record);
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }


    /**
     * @param Connection $conn
     * @param int $orderId
     * 
     * @return CustomerOrderItem[]
     */
    public static function findByOrderId(Connection $conn, int $orderId): array
    {
        $orderItems = [];
        try{
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("customer_order_details")
                ->where("order_id = ?")           
                ->setParameter(0, $orderId)
                ->executeQuery()
                ->fetchAllAssociative();
            foreach($records as $record){
                $orderItems[] = self::getobject($record);
            }
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }    
        return $orderItems; 
    }

    /**
     * @param Connection $conn
     * 
     * @return Product
     */
    public function getProduct(Connection $conn): Product
    {
        return Product::findById($conn, $this->productId);
    }

}