<?php
namespace Polytropic\EcommBackend\models;

use Exception;
use DateTime;
use Doctrine\DBAL\Connection;

class AppUserLogin implements ModelInterface{

    private int $id;
    private int $customerId;
    private string $accountPassword;
    private ?DateTime $lastLoginOn;


    /**
     * Get the value of id
     */ 
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId(int $id): AppUserLogin
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of customerId
     */ 
    public function getCustomerId(): string
    {
        return $this->customerId;
    }

    /**
     * Set the value of customerId
     *
     * @return  self
     */ 
    public function setCustomerId(string $customerId): AppUserLogin
    {
        $this->customerId = $customerId;

        return $this;
    }

    /**
     * Get the value of accountPassword
     */ 
    public function getAccountPassword(): string
    {
        return $this->accountPassword;
    }

    /**
     * Set the value of accountPassword
     *
     * @return  self
     */ 
    public function setAccountPassword(string $accountPassword): AppUserLogin
    {
        $this->accountPassword = $accountPassword;

        return $this;
    }

    /**
     * Get the value of lastLoginOn
     */ 
    public function getLastLoginOn(): ?DateTime
    {
        return $this->lastLoginOn;
    }

    /**
     * Set the value of lastLoginOn
     *
     * @return  self
     */ 
    public function setLastLoginOn(?DateTime $lastLoginOn): AppUserLogin
    {
        $this->lastLoginOn = $lastLoginOn;

        return $this;
    }


    public function insert(Connection $conn): AppUserLogin
    {
        try{
            $conn->createQueryBuilder()
                ->insert("app_user_login")
                ->values([
                    "customer_id" => "?",
                    "account_password" => "?"
                ])->setParameters([
                    $this->customerId,
                    $this->accountPassword
                ])->executeStatement();
            $this->id = $conn->lastInsertId();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
        return $this;
    }

    public function save(Connection $conn): AppUserLogin
    {
        try{
            $conn->createQueryBuilder()
                ->update("app_user_login")
                ->set("customer_id", "?")
                ->set("account_password", "?")
                ->set("last_login_on", "?")
                ->where("id = ?")
                ->setParameters([
                    $this->customerId,
                    $this->accountPassword,
                    is_null($this->lastLoginOn) ? null : $this->lastLoginOn->format("Y-m-d H:i:s"),
                    $this->id
                ])->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
        return $this;
    }

    public function delete(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->delete("app_user_login")
                ->where("id = ?")
                ->setParameter(0, $this->id)
                ->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    private static function getObject(array $record): AppUserLogin
    {
        return (new AppUserLogin())
            ->setId($record["id"])
            ->setCustomerId($record["customer_id"])
            ->setAccountPassword($record["account_password"])
            ->setLastLoginOn(is_null($record["last_login_on"]) ? null : DateTime::createFromFormat("Y-m-d H:i:s", $record["last_login_on"]));
    }

    public static function findById(Connection $conn, int $recordId): ?AppUserLogin
    {
        $record = $conn->createQueryBuilder()
            ->select("*")
            ->from("app_user_login")
            ->where("id = ?")
            ->setParameter(0, $recordId)
            ->executeQuery()
            ->fetchAssociative();
        if(!$record) return null;
        return self::getObject($record);
    }

    public static function findByCustomerId(Connection $conn, int $customerId): ?AppUserLogin
    {
        $record = $conn->createQueryBuilder()
            ->select("*")
            ->from("app_user_login")
            ->where("customer_id = ?")
            ->setParameter(0, $customerId)
            ->executeQuery()
            ->fetchAssociative();
        if(!$record) return null;
        return self::getObject($record);
    }

}