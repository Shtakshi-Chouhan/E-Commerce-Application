<?php
namespace Polytropic\EcommBackend\models;

use Doctrine\DBAL\Connection;

interface ModelInterface{
    function insert(Connection $conn);
    function save(Connection $conn);
    function delete(Connection $conn);
}