<?php
namespace Polytropic\EcommBackend\models;

use Exception;
use DateTime;
use Doctrine\DBAL\Connection;

class AdminUser implements ModelInterface{

    private $id;
    private $firstName;
    private $lastName;
    private $emailAddress;
    private $password;
    private $isSuperAdmin;
    private $lastLoggedIn;
    private $isAccountActive;

    public function getId():int{
        return $this->id;
    }    

    public function setId(int $value): AdminUser{
        $this->id = $value;
        return $this;
    }

    public function getFirstName(): string{
        return $this->firstName;
    }    

    public function setFirstName(string $value): AdminUser{
        $this->firstName = $value;
        return $this;
    }

    public function getLastName():string{
        return $this->lastName;
    }

    public function setLastName(string $value): AdminUser{
        $this->lastName = $value;
        return $this;
    }

    public function getEmailAddress(): string{
        return $this->emailAddress;
    }

    public function setEmailAddress(string $value): AdminUser{
        if(filter_var($value, FILTER_VALIDATE_EMAIL)){
            $this->emailAddress = $value;
        }else{
            throw new Exception("Invalid email address passed.");
        }
        return $this;
    }

    public function getPassword(): string{
        return $this->password;
    }

    public function setPassword(string $value): AdminUser{
        $this->password = $value;
        return $this;
    }

    public function getIsSuperAdmin(): bool{
        return $this->isSuperAdmin;        
    }

    public function setIsSuperAdmin(bool $value): AdminUser{
        $this->isSuperAdmin = $value;
        return $this;
    }

    public function getIsAccountActive(): bool{
        return $this->isAccountActive;        
    }

    public function setIsAccountActive(bool $value): AdminUser{
        $this->isAccountActive = $value;
        return $this;
    }    

    public function getLastLoggedIn(): DateTime{
        return new DateTime($this->lastLoggedIn);
    }

    public function setLastLoggedIn(DateTime $value): AdminUser{
        $this->lastLoggedIn = $value->format("Y-m-d H:i:s");
        return $this;
    }
    
    public function insert(Connection $conn){
        try{
            $conn->createQueryBuilder()
                ->insert("admin_user")
                ->values([
                    "first_name" => "?",
                    "last_name" => "?",
                    "email_address" => "?",
                    "account_password" => "?",
                    "is_super_admin" => "?",
                    "is_active" => "?"
                ])->setParameters([
                    $this->getFirstName(),
                    $this->getLastName(),
                    $this->getEmailAddress(),
                    $this->getPassword(),
                    $this->getIsSuperAdmin() ? 1 : 0,
                    $this->getIsAccountActive() ? 1 : 0
                ])->executeQuery();
            $this->setId($conn->lastInsertId());
        }catch(Exception $e){
            throw new Exception("Database operation Failed. Please re-try again.");
        }
    }
    
    public function save(Connection $conn){
        try{
            $qb = $conn->createQueryBuilder()
                ->update("admin_user")
                ->set("first_name", "?")
                ->set("last_name", "?")
                ->set("email_address", "?")
                ->set("account_password", "?")
                ->set("is_super_admin", "?")
                ->set("is_active", "?")
                ->set("last_logged_in", "?")
                ->where("id = ?")
                ->setParameters([
                    $this->getFirstName(),
                    $this->getLastName(),
                    $this->getEmailAddress(),
                    $this->getPassword(),
                    $this->getIsSuperAdmin() ? 1 : 0,
                    $this->getIsAccountActive() ? 1 : 0,
                    $this->getLastLoggedIn()->format("Y-m-d H:i"), 
                    $this->getId()
                ])
                ->executeStatement();
        }catch(Exception $e){
            echo $e->getMessage();
            throw new Exception("Database operation Failed. Please re-try again.");
        }
    }
    
    public function delete(Connection $conn){
        try{
            $conn->createQueryBuilder()
                ->delete("admin_user")
                ->where("id = ?")
                ->setParameter(0, $this->getId())
                ->executeQuery();
        }catch(Exception $e){
            throw new Exception("Database operation Failed. Please re-try again.");
        }
    }

    private static function getAdminUserObject(array $user): AdminUser{
        $adminUser = new AdminUser();
        $adminUser
            ->setId($user["id"])
            ->setFirstName($user["first_name"])
            ->setLastName($user["last_name"])
            ->setEmailAddress($user["email_address"])
            ->setPassword($user["account_password"])
            ->setIsSuperAdmin($user["is_super_admin"] == 1)
            ->setIsAccountActive($user["is_active"] == 1);
        if(!is_null($user["last_logged_in"]))
            $adminUser->setLastLoggedIn(new DateTime($user["last_logged_in"]));
        return $adminUser;
    }

    public static function findById(Connection $conn, int $id): AdminUser{
        $user = false;
        try{
            $user = $conn
                ->createQueryBuilder()
                ->select("*")
                ->from("admin_user")
                ->where("id = ?")
                ->setParameter(0, $id)
                ->executeQuery()
                ->fetchAssociative();
        }catch(Exception $e){
            throw new Exception("Database Operation failed. Please re-try again.");
        }
        if($user === false)
            throw new Exception("No admin user account found matching specified \"id\"");
        return AdminUser::getAdminUserObject($user);
    }

    public static function findByEmailAddress(Connection $conn, string $emailAddress): AdminUser{
        $user = false;
        try{
            $user = $conn
                ->createQueryBuilder()
                ->select("*")
                ->from("admin_user")
                ->where("email_address = ?")
                ->setParameter(0, $emailAddress)
                ->executeQuery()
                ->fetchAssociative();
        }catch(Exception $e){
            throw new Exception("Database Operation failed. Please re-try again.");
        }
        if($user === false)
            throw new Exception("No admin user account found matching entered details.");
        return AdminUser::getAdminUserObject($user);
    }

    public static function findAll(Connection $conn): array {
        $users = [];
        try{
            $users = $conn
                ->createQueryBuilder()
                ->select("*")
                ->from("admin_user")
                ->where("is_super_admin = 0")
                ->executeQuery()
                ->fetchAllAssociative();
        }catch(Exception $e){
            throw new Exception("Database Operation failed. Please re-try again.");
        }
        $adminUsers = [];
        foreach($users as $user){
            $adminUsers[] = AdminUser::getAdminUserObject($user);
        }
        return $adminUsers;
    }

    public static function checkEmailAddressExistence(Connection $conn, string $emailAddress): bool{
        try{
            $userCount = $conn->createQueryBuilder()
                ->select("count(*)")
                ->from("admin_user")
                ->where("email_address = ?")
                ->setParameter(0, $emailAddress)
                ->executeQuery()
                ->fetchOne();
            return ($userCount > 0);
        }catch(Exception $e){
            throw new Exception("Database Operation failed. Please re-try again.");
        }
    }

}

