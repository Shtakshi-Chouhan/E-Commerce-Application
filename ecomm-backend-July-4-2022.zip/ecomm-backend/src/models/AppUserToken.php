<?php
namespace Polytropic\EcommBackend\models;

use Exception;
use DateTime;
use Doctrine\DBAL\Connection;

class AppUserToken implements ModelInterface{

    private int $id;
    private int $customerId;
    private string $token;
    private DateTime $tokenIssueDate;
    private DateTime $tokenExpiryDate;

    /**
     * Get the value of id
     */ 
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId(int $id): AppUserToken
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of customerId
     */ 
    public function getCustomerId(): int
    {
        return $this->customerId;
    }

    /**
     * Set the value of customerId
     *
     * @return  self
     */ 
    public function setCustomerId(int $customerId): AppUserToken
    {
        $this->customerId = $customerId;

        return $this;
    }

    /**
     * Get the value of token
     */ 
    public function getToken(): string
    {
        return $this->token;
    }

    /**
     * Set the value of token
     *
     * @return  self
     */ 
    public function setToken(string $token): AppUserToken
    {
        $this->token = $token;

        return $this;
    }

    /**
     * Get the value of tokenIssueDate
     */ 
    public function getTokenIssueDate(): DateTime
    {
        return $this->tokenIssueDate;
    }

    /**
     * Set the value of tokenIssueDate
     *
     * @return  self
     */ 
    public function setTokenIssueDate(DateTime $tokenIssueDate): AppUserToken
    {
        $this->tokenIssueDate = $tokenIssueDate;

        return $this;
    }

    /**
     * Get the value of tokenExpiryDate
     */ 
    public function getTokenExpiryDate(): DateTime
    {
        return $this->tokenExpiryDate;
    }

    /**
     * Set the value of tokenExpiryDate
     *
     * @return  self
     */ 
    public function setTokenExpiryDate(DateTime $tokenExpiryDate): AppUserToken
    {
        $this->tokenExpiryDate = $tokenExpiryDate;

        return $this;
    }

    public function insert(Connection $conn): AppUserToken
    {
        try{
            $conn->createQueryBuilder()
                ->insert("app_user_token")
                ->values([
                    "customer_id" => "?",
                    "token" => "?",
                    "token_issue_date" => "?",
                    "token_expiry_date" => "?"
                ])->setParameters([
                    $this->customerId,
                    $this->token,
                    $this->tokenIssueDate->format("Y-m-d H:i:s"),
                    $this->tokenExpiryDate->format("Y-m-d H:i:s")
                ])->executeStatement();
            $this->id = $conn->lastInsertId();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
        return $this;
    }

    public function save(Connection $conn): AppUserToken
    {
        try{
            $conn->createQueryBuilder()
                ->update("app_user_token")
                ->set("customer_id", "?")
                ->set("token", "?")
                ->set("token_issue_date", "?")
                ->set("token_expiry_date", "?")
                ->where("id = ?")
                ->setParameters([
                    $this->customerId,
                    $this->token,
                    $this->tokenIssueDate->format("Y-m-d H:i:s"),
                    $this->tokenExpiryDate->format("Y-m-d H:i:s"),
                    $this->id
                ])->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
        return $this;
    }

    public function delete(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->delete("app_user_token")
                ->where("id = ?")
                ->setParameter(0, $this->id)
                ->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    private static function getObject(array $record): AppUserToken
    {
        return (new AppUserToken())
            ->setId($record["id"])
            ->setCustomerId($record["customer_id"])
            ->setToken($record["token"])
            ->setTokenIssueDate(DateTime::createFromFormat("Y-m-d H:i:s", $record["token_issue_date"]))
            ->setTokenExpiryDate(DateTime::createFromFormat("Y-m-d H:i:s", $record["token_expiry_date"]));
    }

    public static function findById(Connection $conn, int $recordId): ?AppUserToken
    {
        $record = $conn->createQueryBuilder()
            ->select("*")
            ->from("app_user_token")
            ->where("id = ?")
            ->setParameter(0, $recordId)
            ->executeQuery()
            ->fetchAssociative();
        if(!$record) return null;
        return self::getObject($record);
    }

    public static function findByCustomerId(Connection $conn, int $customerId): ?AppUserToken
    {
        $record = $conn->createQueryBuilder()
            ->select("*")
            ->from("app_user_token")
            ->where("customer_id = ?")
            ->setParameter(0, $customerId)
            ->executeQuery()
            ->fetchAssociative();
        if(!$record) return null;
        return self::getObject($record);
    }

    public static function findByToken(Connection $conn, string $token): ?AppUserToken
    {
        $record = $conn->createQueryBuilder()
            ->select("*")
            ->from("app_user_token")
            ->where("token = ?")
            ->setParameter(0, $token)
            ->executeQuery()
            ->fetchAssociative();
        if(!$record) return null;
        return self::getObject($record);
    }
}    