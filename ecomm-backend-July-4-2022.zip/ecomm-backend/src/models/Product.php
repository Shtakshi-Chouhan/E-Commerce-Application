<?php
namespace Polytropic\EcommBackend\models;

use Doctrine\DBAL\Connection;
use Exception;
use Throwable;

class Product implements ModelInterface{

    private int $id;
    private int $categoryId;
    private string $title;
    private string $description;
    private float $sellingPrice;
    private bool $isInStock;
    private bool $isVisible;
    private string $featuredImage;

    public function getId(): int {
        return $this->id;
    }

    public function setId(int $value){
        $this->id = $value;
        return $this;
    }

    public function getCategoryId(): int {
        return $this->categoryId;
    }

    public function setCategoryId(int $value){
        $this->categoryId = $value;
        return $this;
    }

    public function getTitle(): string{
        return $this->title;
    }

    public function setTtile(string $value){
        $this->title = $value;
        return $this;
    }

    public function getDescription(): string{
        return $this->description;
    }

    public function setDescription(string $value){
        $this->description = $value;
        return $this;
    }

    public function getSellingPrice(): float{
        return $this->sellingPrice;
    }

    public function setSellingPrice(float $value){
        $this->sellingPrice = $value;
        return $this;
    }

    public function getIsInStock(): bool{
        return $this->isInStock;
    } 

    public function setIsInStock(bool $value){
        $this->isInStock = $value;
        return $this;
    }

    public function getIsVisible(): bool{
        return $this->isVisible;
    }

    public function setIsVisible(bool $value){
        $this->isVisible = $value;
        return $this;
    }

    public function getFeaturedImage(): string{
        return $this->featuredImage;
    }

    public function setfeaturedImage(string $value){
        $this->featuredImage = $value;
        return $this;
    }

    /**
     * @param Connection $conn
     * 
     * @return void
     */
    public function insert(Connection $conn): void
    {
        try{
            $conn->createQueryBuilder()
                ->insert("product")
                ->values([
                    "category_id" => "?",
                    "title" => "?",
                    "description" => "?",
                    "selling_price" => "?",
                    "is_in_stock" => "?",
                    "is_visible" => "?",
                    "featured_image" => "?"
                ])->setParameters([
                    $this->categoryId,
                    $this->title,
                    $this->description,
                    $this->sellingPrice,
                    $this->isInStock ? 1 : 0,
                    $this->isVisible ? 1 : 0,
                    $this->featuredImage
                ])->executeStatement();
            $this->id = $conn->lastInsertId();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * 
     * @return void
     */
    public function save(Connection $conn): void
    {
        try{
            $conn->createQueryBuilder()
                ->update("product")
                ->set("category_id", "?")
                ->set("title", "?")
                ->set("description", "?")
                ->set("selling_price", "?")
                ->set("is_in_stock", "?")
                ->set("is_visible", "?")
                ->set("featured_image", "?")
                ->where("id = ?")
                ->setParameters([
                    $this->categoryId,
                    $this->title,
                    $this->description,
                    $this->sellingPrice,
                    $this->isInStock ? 1 : 0,
                    $this->isVisible ? 1 : 0,
                    $this->featuredImage,
                    $this->id
                ])->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operatiion failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * 
     * @return void
     */
    public function delete(Connection $conn): void
    {
        try{
            $conn->createQueryBuilder()
                ->delete("product")
                ->where("id = ?")
                ->setParameter(0, $this->id)
                ->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operatiion failed. Please re-try again.");
        }
    }

    /**
     * @param array $record
     * 
     * @return Product
     */
    private static function getObject(array $record): Product
    {
        $product = new Product();
        $product->setId($record["id"])
            ->setCategoryId($record["category_id"])
            ->setTtile($record["title"])
            ->setDescription($record["description"])
            ->setSellingPrice($record["selling_price"])
            ->setIsInStock($record["is_in_stock"] == 1)
            ->setIsVisible($record["is_visible"] == 1)
            ->setFeaturedImage($record["featured_image"]);
        return $product;
    }

    /**
     * @param Connection $conn
     * @param int $id
     * 
     * @return Product|null
     */
    public static function findById(Connection $conn, int $id): ?Product
    {
        try{
            $record = $conn->createQueryBuilder()
                ->select("*")
                ->from("product")
                ->where("id = ?")
                ->setParameter(0, $id)
                ->executeQuery()
                ->fetchAssociative();
            if(!$record) return null;
            return self::getObject($record);
        }catch(Exception $e){
            throw new Exception("Database operatiion failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * 
     * @return int
     */
    public static function getRecordCount(Connection $conn): int
    {
        try{
            return $conn->createQueryBuilder()
                ->select("count(*)")
                ->from("product")
                ->executeQuery()
                ->fetchOne();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * @param int $pageSize
     * 
     * @return int
     */
    public static function getTotalPages(Connection $conn, int $pageSize = 25): int
    {
        try{
            $totalRecords = self::getRecordCount($conn);
            return ceil($totalRecords / $pageSize);
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * @param int $pageNumber
     * @param int $pageSize
     * 
     * @return Product[]
     */
    public static function getPage(Connection $conn, int $pageNumber = 1, int $pageSize = 25): array
    {
        try{
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("product")
                ->setFirstResult(($pageNumber - 1) * $pageSize)
                ->setMaxResults($pageSize)
                ->executeQuery()
                ->fetchAllAssociative();
            $pageRecords = [];
            foreach($records as $record){
                $pageRecords[] = self::getObject($record);
            }
            return $pageRecords;
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }
    

    /**
     * @param Connection $conn
     * @param int $categoryId
     * @param int $pageNumber
     * @param int $pageSize
     * 
     * @return Product[]
     */
    public static function getPageByCategory(Connection $conn, int $categoryId, int $pageNumber = 1, int $pageSize = 25): array
    {
        try {
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("product")
                ->where("category_id = ?")
                ->setParameter(0, $categoryId)
                ->setFirstResult(($pageNumber - 1) * $pageSize)
                ->setMaxResults($pageSize)
                ->executeQuery()
                ->fetchAllAssociative();
            $pageRecords = [];
            foreach($records as $record){
                $pageRecords[] = self::getObject($record);
            }
            return $pageRecords;
        } catch (Throwable $e) {
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * @param int $categoryId
     * 
     * @return array
     */
    public static function getAllByCategory(Connection $conn, int $categoryId): array
    {
        try {
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("product")
                ->where("category_id = ?")
                ->setParameter(0, $categoryId)
                ->fetchAllAssociative();
            $pageRecords = [];
            foreach($records as $record){
                $pageRecords[] = self::getObject($record);
            }
            return $pageRecords;
        } catch (Throwable $e) {
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }
}