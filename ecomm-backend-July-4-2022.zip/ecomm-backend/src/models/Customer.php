<?php
namespace Polytropic\EcommBackend\models;

use Doctrine\DBAL\Connection;
use Exception;
use DateTime;

class Customer implements ModelInterface{

    private int $id;
    private string $firstName;
    private string $lastName;
    private string $emailAddress;
    private string $mobileNumber;
    private ?string $altMobileNumber = null;
    private DateTime $registeredOn;
    private bool $accountVerified;
    private ?string $accountOTP = null;
    private bool $accountEnabled;

    /**
     * Get the value of id
     */ 
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId(int $id): Customer
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Get the value of firstName
     */ 
    public function getFirstName(): string
    {
        return $this->firstName;
    }

    /**
     * Set the value of firstName
     *
     * @return  self
     */ 
    public function setFirstName(string $firstName): Customer
    {
        $this->firstName = $firstName;
        return $this;
    }

    /**
     * Get the value of lastName
     */ 
    public function getLastName(): string
    {
        return $this->lastName;
    }

    /**
     * Set the value of lastName
     *
     * @return  self
     */ 
    public function setLastName(string $lastName): Customer
    {
        $this->lastName = $lastName;
        return $this;
    }

    /**
     * Get the value of emailAddress
     */ 
    public function getEmailAddress(): string
    {
        return $this->emailAddress;
    }

    /**
     * Set the value of emailAddress
     *
     * @return  self
     */ 
    public function setEmailAddress(string $emailAddress): Customer
    {
        $this->emailAddress = $emailAddress;
        return $this;
    }

    /**
     * Get the value of mobileNumber
     */ 
    public function getMobileNumber(): string
    {
        return $this->mobileNumber;
    }

    /**
     * Set the value of mobileNumber
     *
     * @return  self
     */ 
    public function setMobileNumber(string $mobileNumber): Customer
    {
        $this->mobileNumber = $mobileNumber;
        return $this;
    }

    /**
     * Get the value of altMobileNumber
     */ 
    public function getAltMobileNumber(): ?string 
    {
        return $this->altMobileNumber;
    }

    /**
     * Set the value of altMobileNumber
     *
     * @return  self
     */ 
    public function setAltMobileNumber(?string $altMobileNumber): Customer
    {
        $this->altMobileNumber = $altMobileNumber;
        return $this;
    }

    /**
     * Get the value of registeredOn
     */ 
    public function getRegisteredOn(): DateTime
    {
        return $this->registeredOn;
    }

    /**
     * Set the value of registeredOn
     *
     * @return  self
     */ 
    public function setRegisteredOn(DateTime $registeredOn): Customer
    {
        $this->registeredOn = $registeredOn;
        return $this;
    }

    /**
     * Get the value of accountVerified
     */ 
    public function getAccountVerified(): bool
    {
        return $this->accountVerified;
    }

    /**
     * Set the value of accountVerified
     *
     * @return  self
     */ 
    public function setAccountVerified(bool $accountVerified)
    {
        $this->accountVerified = $accountVerified;
        return $this;
    }

    /**
     * Get the value of accountOTP
     */ 
    public function getAccountOTP(): ?string
    {
        return $this->accountOTP;
    }

    /**
     * Set the value of accountOTP
     *
     * @return  self
     */ 
    public function setAccountOTP(?string $accountOTP): Customer
    {
        $this->accountOTP = $accountOTP;
        return $this;
    }

    /**
     * Get the value of accountEnabled
     */ 
    public function getAccountEnabled(): bool
    {
        return $this->accountEnabled;
    }

    /**
     * Set the value of accountEnabled
     *
     * @return  self
     */ 
    public function setAccountEnabled(bool $accountEnabled): Customer
    {
        $this->accountEnabled = $accountEnabled;
        return $this;
    }

    public function insert(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->insert("customer")
                ->values([
                    "first_name" => "?",
                    "last_name" => "?",
                    "email_address" => "?",
                    "mobile_number" => "?",
                    "alt_mobile_number" => "?",
                    "registered_on" => "?",
                    "account_verified" => "?",
                    "account_otp" => "?",
                    "account_enabled" => "?"
                ])->setParameters([
                    $this->firstName,
                    $this->lastName,
                    $this->emailAddress,
                    $this->mobileNumber,
                    $this->altMobileNumber,
                    $this->registeredOn->format("Y-m-d H:i:s"),
                    $this->accountVerified ? 1 : 0,
                    $this->accountOTP,
                    $this->accountEnabled ? 1 : 0
                ])->executeStatement();
            $this->id = $conn->lastInsertId();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function save(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->update("customer")
                ->set("first_name", "?")
                ->set("last_name", "?")
                ->set("email_address", "?")
                ->set("mobile_number", "?")
                ->set("alt_mobile_number", "?")
                ->set("registered_on", "?")
                ->set("account_verified", "?")
                ->set("account_otp", "?")
                ->set("account_enabled", "?")
                ->where("id = ?")
                ->setParameters([
                    $this->firstName,
                    $this->lastName,
                    $this->emailAddress,
                    $this->mobileNumber,
                    $this->altMobileNumber,
                    $this->registeredOn->format("Y-m-d H:i:s"),
                    $this->accountVerified ? 1 : 0,
                    $this->accountOTP,
                    $this->accountEnabled ? 1 : 0,
                    $this->id
                ])->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function delete(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->delete("customer")
                ->where("id = ?")
                ->setParameter(0, $this->id)
                ->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    private static function getObject(array $record): Customer{
        $object = new Customer();
        $object
            ->setId($record["id"])
            ->setFirstName($record["first_name"])
            ->setLastName($record["last_name"])
            ->setEmailAddress($record["email_address"])
            ->setMobileNumber($record["mobile_number"])
            ->setAltMobileNumber($record["alt_mobile_number"])
            ->setRegisteredOn(DateTime::createFromFormat("Y-m-d H:i:s", $record["registered_on"]))
            ->setAccountVerified($record["account_verified"] == 1)
            ->setAccountOTP($record["account_otp"])
            ->setAccountEnabled($record["account_enabled"] == 1);
        return $object;
    }

    public static function findById(Connection $conn, int $id): Customer{
        $record = false;
        try{
            $record = $conn
                ->createQueryBuilder()
                ->select("*")
                ->from("customer")
                ->where("id = ?")
                ->setParameter(0, $id)
                ->executeQuery()
                ->fetchAssociative();
        }catch(Exception $e){
            throw new Exception("Database Operation failed. Please re-try again.");
        }
        if($record === false)
            throw new Exception("No product image found matching specified \"id\"");
        return self::getObject($record);
    }

    /**
     * @param Connection $conn
     * 
     * @return int
     */
    public static function getRecordCount(Connection $conn): int
    {
        try{
            return $conn->createQueryBuilder()
                ->select("count(*)")
                ->from("customer")
                ->executeQuery()
                ->fetchOne();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * @param int $pageSize
     * 
     * @return int
     */
    public static function getTotalPages(Connection $conn, int $pageSize = 25): int
    {
        try{
            $totalRecords = self::getRecordCount($conn);
            return ceil($totalRecords / $pageSize);
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * @param int $pageNumber
     * @param int $pageSize
     * 
     * @return Customer[]
     */
    public static function getPage(Connection $conn, int $pageNumber = 1, int $pageSize = 25): array
    {
        try{
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("customer")
                ->setFirstResult(($pageNumber - 1) * $pageSize)
                ->setMaxResults($pageSize)
                ->executeQuery()
                ->fetchAllAssociative();
            $pageRecords = [];
            foreach($records as $record){
                $pageRecords[] = self::getObject($record);
            }
            return $pageRecords;
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public static function getByEmailAddress(Connection $conn, string $emailAddress): ?Customer
    {
        $record = $conn->createQueryBuilder()
            ->select("*")
            ->from("customer")
            ->where("email_address = ?")
            ->setParameter(0, $emailAddress)
            ->executeQuery()
            ->fetchAssociative();
        if(!$record) return null;
        return self::getObject($record);
    }

    /**
     * @param Connection $conn
     * @param string $firstName
     * 
     * @return Customer[]
     */
    public static function searchByFirstName(Connection $conn, string $firstName): array
    {
        try{
            $customers = [];
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("customer")
                ->where("first_name LIKE ?")
                ->setParameter(0, "%".$firstName."%")
                ->executeQuery()
                ->fetchAllAssociative();
            foreach($records as $record){
                $customers[] = self::getObject($record);
            }
            return $customers;
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * @param string $emailAddress
     * 
     * @return Customer[]
     */
    public static function searchByEmailAddress(Connection $conn, string $emailAddress): array
    {
        try{
            $customers = [];
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("customer")
                ->where("email_address LIKE ?")
                ->setParameter(0, "%".$emailAddress."%")
                ->executeQuery()
                ->fetchAllAssociative();
            foreach($records as $record){
                $customers[] = self::getObject($record);
            }
            return $customers;
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * @param string $emailAddress
     * 
     * @return Customer[]
     */
    public static function searchByMobileNumber(Connection $conn, string $mobileNumber): array
    {
        try{
            $customers = [];
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("customer")
                ->where("mobile_number LIKE ?")
                ->setParameter(0, "%".$mobileNumber."%")
                ->executeQuery()
                ->fetchAllAssociative();
            foreach($records as $record){
                $customers[] = self::getObject($record);
            }
            return $customers;
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }
}