<?php
namespace Polytropic\EcommBackend\models;

use Doctrine\DBAL\Connection;
use Exception;
use DateTime;

class CustomerOrder implements ModelInterface{
    private int $id;
    private int $customerId;
    private DateTime $orderedOn;
    private float $subTotal;
    private float $discount;
    private float $taxes;
    private float $shippingCharges;
    private string $status;
    private ?string $notes = null;
    private int $customerBillingAddressId;
    private int $customerShippingAddressId;
    
    /**
     * Get the value of id
     */ 
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId(int $id): CustomerOrder
    {
        $this->id = $id;
        return $this;
    }
    /**
     * Get the value of customerId
     */ 
    public function getCustomerId(): int
    {
        return $this->customerId;
    }

    /**
     * Set the value of customerId
     *
     * @return  self
     */ 
    public function setCustomerId(int $customerId): CustomerOrder
    {
        $this->customerId = $customerId;
        return $this;
    }
    
    public function getOrderedOn(): DateTime{
        return $this->orderedOn;
    }
    public function setOrderedOn(DateTime $orderedOn): CustomerOrder
    {
        $this->orderedOn = $orderedOn;
        return $this;
    }
    
    public function getSubTotal(): float
    {
        return $this->subTotal;
    }

    public function setSubTotal(float $subTotal): CustomerOrder
    {
        $this->subTotal = $subTotal;
        return $this;
    }
    
    public function getDiscount(): float
    {
        return $this->discount;
    }

    public function setDiscount(float $discount): CustomerOrder
    {
        $this->discount = $discount;
        return $this;
    }
    
    public function getTaxes(): float
    {
        return $this->taxes;
    }

    public function setTaxes(float $taxes): CustomerOrder
    {
        $this->taxes = $taxes;
        return $this;
    }
    
    public function getShippingCharges(): float
    {
        return $this->shippingCharges;
    }

    public function setShippingCharges(float $shippingCharges): CustomerOrder
    {
        $this->shippingCharges = $shippingCharges;
        return $this;
    }
    
    public function getStatus(): string{
        return $this->status;
    }

    public function setStatus(string $status): CustomerOrder
    {
        $this->status = $status;
        return $this;
    }
    
    public function getNotes(): ?string{
        return $this->notes;
    }

    public function setNotes(?string $notes): CustomerOrder
    {
        $this->notes = $notes;
        return $this;
    }
    
    public function getCustomerBillingAddressId(): int
    {
        return $this->customerBillingAddressId;
    }

    public function setCustomerBillingAddressId(int $customerBillingAddressId): CustomerOrder
    {
        $this->customerBillingAddressId = $customerBillingAddressId;
        return $this;
    }
    
    public function getCustomerShippingAddressId(): int
    {
        return $this->customerShippingAddressId;
    }

    public function setCustomerShippingAddressId(int $customerShippingAddressId): CustomerOrder
    {
        $this->customerShippingAddressId = $customerShippingAddressId;
        return $this;
    }
    
    public function insert(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->insert("customer_order")
                ->values([
                    "customer_id" => "?",
                    "ordered_on" => "?",
                    "subtotal" => "?",
                    "discount" => "?",
                    "taxes" => "?",
                    "shipping_charge" => "?",
                    "status" => "?",
                    "notes" => "?",
                    "customer_billing_address" => "?",
                    "customer_shipping_address" => "?"
                ])->setParameters([
                    $this->customerId,
                    $this->orderedOn->format("Y-m-d H:i:s"),
                    $this->subTotal,
                    $this->discount,
                    $this->taxes,
                    $this->shippingCharges,
                    $this->status,
                    $this->notes,
                    $this->customerBillingAddressId,
                    $this->customerShippingAddressId
                ])->executeStatement();
            $this->id = $conn->lastInsertId();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function save(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->update("customer_order")
                ->set("customer_id", "?")
                ->set("ordered_on", "?")
                ->set("subtotal", "?")
                ->set("discount", "?")
                ->set("taxes", "?")
                ->set("shipping_charge", "?")
                ->set("status", "?")
                ->set("notes", "?")
                ->set("customer_billing_address", "?")
                ->set("customer_shipping_address", "?")
                ->where("id = ?")
                ->setParameters([
                    $this->customerId,
                    $this->orderedOn->format("Y-m-d H:i:s"),
                    $this->subTotal,
                    $this->discount,
                    $this->taxes,
                    $this->shippingCharges,
                    $this->status,
                    $this->notes,
                    $this->customerBillingAddressId,
                    $this->customerShippingAddressId,
                    $this->id
                ])->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function delete(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->delete("customer_order")
                ->where("id = ?")
                ->setParameter(0, $this->id)
                ->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public static function getObject(array $record): CustomerOrder
    {
        return (new CustomerOrder())
            ->setId($record["id"])
            ->setCustomerId($record["customer_id"])
            ->setOrderedOn(DateTime::createFromFormat("Y-m-d H:i:s", $record["ordered_on"]))
            ->setSubTotal($record["subtotal"])
            ->setDiscount($record["discount"])
            ->setTaxes($record["taxes"])
            ->setShippingCharges($record["shipping_charge"])
            ->setStatus($record["status"])
            ->setNotes($record["notes"])
            ->setCustomerBillingAddressId($record["customer_billing_address"])
            ->setCustomerShippingAddressId($record["customer_shipping_address"]);
    }

    public static function findById(Connection $conn, int $id): ?CustomerOrder
    {
        try{
            $record = $conn->createQueryBuilder()
                ->select("*")
                ->from("customer_order")
                ->where("id = ?")
                ->setParameter(0, $id)
                ->executeQuery()
                ->fetchAssociative();
            if(!$record) return null;
            return self::getObject($record);
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * 
     * @return int
     */
    public static function getRecordCount(Connection $conn): int
    {
        try{
            return $conn->createQueryBuilder()
                ->select("count(*)")
                ->from("customer_order")
                ->executeQuery()
                ->fetchOne();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * @param int $pageSize
     * 
     * @return int
     */
    public static function getTotalPages(Connection $conn, int $pageSize = 25): int
    {
        try{
            $totalRecords = self::getRecordCount($conn);
            return ceil($totalRecords / $pageSize);
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * @param int $pageNumber
     * @param int $pageSize
     * 
     * @return CustomerOrders[]
     */
    public static function getPage(Connection $conn, int $pageNumber = 1, int $pageSize = 25): array
    {
        try{
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("customer_order")
                ->setFirstResult(($pageNumber - 1) * $pageSize)
                ->setMaxResults($pageSize)
                ->executeQuery()
                ->fetchAllAssociative();
            $pageRecords = [];
            foreach($records as $record){
                $pageRecords[] = self::getObject($record);
            }
            return $pageRecords;
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * 
     * @return Customer
     */
    public function getCustomer(Connection $conn): Customer
    {
        return Customer::findById($conn, $this->customerId);
    }

    /**
     * @return string
     */
    public function formattedOrderId(): string
    {
        return "#".str_pad($this->id, 5, "0", STR_PAD_LEFT);
    }
}