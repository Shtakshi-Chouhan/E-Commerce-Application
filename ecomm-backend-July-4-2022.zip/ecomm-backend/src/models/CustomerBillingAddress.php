<?php
namespace Polytropic\EcommBackend\models;

use Doctrine\DBAL\Connection;
use Exception;

class CustomerBillingAddress implements ModelInterface{

    private int $id;
    private int $customerId;
    private string $name;
    private string $addressLine1;
    private ?string $addressLine2 = null;
    private string $city;
    private string $state;
    private string $country;
    private ?string $pincode = null;

    /**
     * Get the value of id
     */ 
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    /**
     * Get the value of customerId
     */ 
    public function getCustomerId()
    {
        return $this->customerId;
    }

    /**
     * Set the value of customerId
     *
     * @return  self
     */ 
    public function setCustomerId($customerId)
    {
        $this->customerId = $customerId;

        return $this;
    }

    /**
     * Get the value of name
     */ 
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set the value of name
     *
     * @return  self
     */ 
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get the value of addressLine1
     */ 
    public function getAddressLine1()
    {
        return $this->addressLine1;
    }

    /**
     * Set the value of addressLine1
     *
     * @return  self
     */ 
    public function setAddressLine1($addressLine1)
    {
        $this->addressLine1 = $addressLine1;

        return $this;
    }

    /**
     * Get the value of addressLine2
     */ 
    public function getAddressLine2()
    {
        return $this->addressLine2;
    }

    /**
     * Set the value of addressLine2
     *
     * @return  self
     */ 
    public function setAddressLine2($addressLine2)
    {
        $this->addressLine2 = $addressLine2;

        return $this;
    }

    /**
     * Get the value of city
     */ 
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set the value of city
     *
     * @return  self
     */ 
    public function setCity($city)
    {
        $this->city = $city;

        return $this;
    }

    /**
     * Get the value of state
     */ 
    public function getState()
    {
        return $this->state;
    }

    /**
     * Set the value of state
     *
     * @return  self
     */ 
    public function setState($state)
    {
        $this->state = $state;

        return $this;
    }

    /**
     * Get the value of country
     */ 
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * Set the value of country
     *
     * @return  self
     */ 
    public function setCountry($country)
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get the value of pincode
     */ 
    public function getPincode()
    {
        return $this->pincode;
    }

    /**
     * Set the value of pincode
     *
     * @return  self
     */ 
    public function setPincode($pincode)
    {
        $this->pincode = $pincode;

        return $this;
    }

    public function insert(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->insert("customer_billing_address")
                ->values([
                    "customer_id" => "?",
                    "name" => "?",
                    "address_line1" => "?",
                    "address_line2" => "?",
                    "city" => "?",
                    "state" => "?",
                    "country" => "?",
                    "pincode" => "?"
                ])->setParameters([
                    $this->customerId,
                    $this->name,
                    $this->addressLine1,
                    $this->addressLine2,
                    $this->city,
                    $this->state,
                    $this->country,
                    $this->pincode
                ])->executeStatement();
            $this->id = $conn->lastInsertId();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function save(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->update("customer_billing_address")
                ->set("customer_id", "?")
                ->set("name", "?")
                ->set("address_line1", "?")
                ->set("address_line2", "?")
                ->set("city", "?")
                ->set("state", "?")
                ->set("country", "?")
                ->set("pincode", "?")
                ->where("id = ?")
                ->setParameters([
                    $this->customerId,
                    $this->name,
                    $this->addressLine1,
                    $this->addressLine2,
                    $this->city,
                    $this->state,
                    $this->country,
                    $this->pincode,
                    $this->id
                ])->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function delete(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->delete("customer_billing_address")
                ->where("id = ?")
                ->setParameter(0, $this->id)
                ->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public static function getObject(array $record): CustomerBillingAddress
    {
        $customerBillingAddress = new CustomerBillingAddress();
        $customerBillingAddress->setId($record["id"])
            ->setCustomerId($record["customer_id"])
            ->setName($record["name"])
            ->setAddressLine1($record["address_line1"])
            ->setAddressLine2($record["address_line2"])
            ->setCity($record["city"])
            ->setState($record["state"])
            ->setCountry($record["country"])
            ->setPincode($record["pincode"]);
        return $customerBillingAddress;
    }

    public static function findById(Connection $conn, int $id): ?CustomerBillingAddress
    {
        try{
            $record = $conn->createQueryBuilder()
                ->select("*")
                ->from("customer_billing_address")
                ->where("id = ?")
                ->setParameter(0, $id)
                ->executeQuery()
                ->fetchAssociative();
            if(!$record) return null;
            return self::getObject($record);
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public static function findByCustomerId(Connection $conn, int $customerId): ?CustomerBillingAddress
    {
        try{
            $record = $conn->createQueryBuilder()
                ->select("*")
                ->from("customer_billing_address")
                ->where("customer_id = ?")
                ->setParameter(0, $customerId)
                ->executeQuery()
                ->fetchAssociative();
            if(!$record) return null;
            return self::getObject($record);
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

}