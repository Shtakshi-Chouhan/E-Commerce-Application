<?php namespace Polytropic\EcommBackend\models;

use Exception;
use Doctrine\DBAL\Connection;

class ProductCategory implements ModelInterface{

    private int $id;
    private ?int $parentCategoryId = null;
    private string $title;
    private string $description;
    private string $bannerImage;
    private bool $isEnabled;

    public function insert(Connection $conn){
        try{
            $conn->createQueryBuilder()
                ->insert("product_category")
                ->values([
                    "parent_category_id" => "?",
                    "title" => "?",
                    "description" => "?",
                    "banner_image" => "?",
                    "is_enabled" => "?"
                ])->setParameters([
                    $this->parentCategoryId,
                    $this->title,
                    $this->description,
                    $this->bannerImage,
                    $this->isEnabled ? 1 : 0
                ])->executeStatement();
            $this->id = $conn->lastInsertId();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function save(Connection $conn){
        try{
            $conn->createQueryBuilder()
                ->update("product_category")
                ->set("parent_category_id", "?")
                ->set("title", "?")
                ->set("description", "?")
                ->set("banner_image", "?")
                ->set("is_enabled", "?")
                ->where("id = ?")
                ->setParameters([
                    $this->parentCategoryId,
                    $this->title,
                    $this->description,
                    $this->bannerImage,
                    $this->isEnabled ? 1 : 0,
                    $this->id
                ])->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function delete(Connection $conn){
        try{
            //checking if category is parent to any other category
            $isParentCategory = (bool)$conn->createQueryBuilder()
                ->select("count(*)")
                ->from("product_category")
                ->where("parent_category_id = ?")
                ->setParameter(0, $this->id)
                ->executeQuery()
                ->fetchOne();
            $hasProduct = (bool)$conn->createQueryBuilder()
                ->select("count(*)")
                ->from("product")
                ->where("category_id = ?")    
                ->setParameter(0, $this->id)
                ->executeQuery()
                ->fetchOne();
            
            if($isParentCategory || $hasProduct)
                throw new Exception("This category cannot be deleted.");

            $conn->createQueryBuilder()
                ->delete("product_category")
                ->where("id = ?")
                ->setParameter(0, $this->id)
                ->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    private static function getObject(array $record): ProductCategory{
        $object = new ProductCategory();
        $object
            ->setId($record["id"])
            ->setParentCategoryId($record["parent_category_id"])
            ->setTitle($record["title"])
            ->setDescription($record["description"])
            ->setBannerImage($record["banner_image"])
            ->setIsEnabled(($record["is_enabled"] == 1));
        return $object;
    }

    public static function findById(Connection $conn, int $id): ProductCategory{
        $record = false;
        try{
            $record = $conn
                ->createQueryBuilder()
                ->select("*")
                ->from("product_category")
                ->where("id = ?")
                ->setParameter(0, $id)
                ->executeQuery()
                ->fetchAssociative();
        }catch(Exception $e){
            throw new Exception("Database Operation failed. Please re-try again.");
        }
        if($record === false)
            throw new Exception("No product category found matching specified \"id\"");
        return ProductCategory::getObject($record);
    }

    public static function getAll(Connection $conn): array{
        $pageRecords = [];
        try{
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("product_category")
                ->orderBy("title", "asc")
                ->executeQuery()
                ->fetchAllAssociative();
            foreach($records as $record){
                $pageRecords[] = self::getObject($record);
            }
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again." . ( WORKING_MODE == "test" ? $e->getMessage() : "" ));
        }
        return $pageRecords;
    }

    /**
     * @param Connection $conn
     * 
     * @return int
     */
    public static function getRecordCount(Connection $conn): int{
        try{
            return $conn->createQueryBuilder()
                ->select("count(*)")
                ->from("product_category")
                ->executeQuery()
                ->fetchOne();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * @param int $pageSize
     * 
     * @return int
     */
    public static function getTotalPages(Connection $conn, int $pageSize = 25): int{
        try{
            $totalRecords = self::getRecordCount($conn);
            return ceil($totalRecords / $pageSize);
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    /**
     * @param Connection $conn
     * @param int $pageNumber
     * @param int $pageSize
     * 
     * @return ProductCategory[]
     */
    public static function getPage(Connection $conn, int $pageNumber = 1, int $pageSize = 25): array 
    {
        $pageRecords = [];
        try{
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("product_category")
                ->setFirstResult(($pageNumber - 1) * $pageSize)
                ->setMaxResults($pageSize)
                ->orderBy("title", "asc")
                ->executeQuery()
                ->fetchAllAssociative();
            foreach($records as $record){
                $pageRecords[] = self::getObject($record);
            }
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again." . ( WORKING_MODE == "test" ? $e->getMessage() : "" ));
        }
        return $pageRecords;
    }

    /**
     * @param Connection $conn
     * @param int $categoryId
     * 
     * @return ProductCategory[]
     */
    public static function getParentHirearchy(Connection $conn, int $categoryId): array{
        $parents = [];
        try{
            $currentCategory = ProductCategory::findById($conn, $categoryId)->getParentCategoryId();
            while($currentCategory != null){
                $parents[] = ProductCategory::findById($conn, $currentCategory);
                $currentCategory = ProductCategory::findById($conn, $currentCategory)->getParentCategoryId();
            }
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again." . ( WORKING_MODE == "test" ? $e->getMessage() : "" ));
        }
        return (empty($parents) ? $parents : array_reverse($parents));
    }

    /**
     * @param Connection $conn
     * 
     * @return ProductCategory[]
     */
    public static function getTopLevelCategory(Connection $conn): array
    {
        $categories = [];
        try{
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("product_category")
                ->where("parent_category_id IS NULL")
                ->andWhere("is_enabled = ?")
                ->setParameter(0, 1)
                ->orderBy("title", "ASC")
                ->executeQuery()
                ->fetchAllAssociative();
            foreach($records as $record){
                $categories[] = self::getObject($record);
            }
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again." . ( WORKING_MODE == "test" ? $e->getMessage() : "" ));
        }

        return $categories;
    }

    /**
     * @param Connection $conn
     * @param int $categoryId
     * 
     * @return ProductCategory[]
     */
    public static function getChildrenCategory(Connection $conn, int $categoryId): array
    {
        $categories = [];
        try{
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("product_category")
                ->where("parent_category_id = ?")
                ->andWhere("is_enabled = ?")
                ->setParameters([ $categoryId, 1 ])
                ->orderBy("title", "ASC")
                ->executeQuery()
                ->fetchAllAssociative();
            foreach($records as $record){
                $categories[] = self::getObject($record);
            }
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again." . ( WORKING_MODE == "test" ? $e->getMessage() : "" ));
        }

        return $categories;
    }
    
    /**
     * Get the value of id
     */ 
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * Set the value of id
     *
     * @return  self
     */ 
    public function setId(int $id): ProductCategory
    {
        $this->id = $id;
        return $this;
    }

    /**
     * Get the value of parentCategoryId
     */ 
    public function getParentCategoryId(): ?int
    {
        return $this->parentCategoryId;
    }

    /**
     * Set the value of parentCategoryId
     *
     * @return  self
     */ 
    public function setParentCategoryId(?int $parentCategoryId): ProductCategory
    {
        $this->parentCategoryId = $parentCategoryId;
        return $this;
    }

    /**
     * Get the value of title
     */ 
    public function getTitle(): string
    {
        return $this->title;
    }

    /**
     * Set the value of title
     *
     * @return  self
     */ 
    public function setTitle(string $title): ProductCategory
    {
        $this->title = $title;
        return $this;
    }

    /**
     * Get the value of description
     */ 
    public function getDescription(): string
    {
        return $this->description;
    }

    /**
     * Set the value of description
     *
     * @return  self
     */ 
    public function setDescription(string $description): ProductCategory
    {
        $this->description = $description;
        return $this;
    }

    /**
     * Get the value of bannerImage
     */ 
    public function getBannerImage(): string
    {
        return $this->bannerImage;
    }

    /**
     * Set the value of bannerImage
     *
     * @return  self
     */ 
    public function setBannerImage(string $bannerImage): ProductCategory
    {
        $this->bannerImage = $bannerImage;

        return $this;
    }

    /**
     * Get the value of isEnabled
     */ 
    public function getIsEnabled(): bool
    {
        return $this->isEnabled;
    }

    /**
     * Set the value of isEnabled
     *
     * @return  self
     */ 
    public function setIsEnabled(bool $isEnabled): ProductCategory
    {
        $this->isEnabled = $isEnabled;
        return $this;
    }
}