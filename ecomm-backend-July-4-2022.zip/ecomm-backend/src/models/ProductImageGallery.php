<?php
namespace Polytropic\EcommBackend\models;

use Doctrine\DBAL\Connection;
use Exception;

class ProductImageGallery implements ModelInterface{

    private int $id;
    private int $productId;
    private string $image;
    private bool $isVisible;
    
    public function getId(): int{
        return $this->id;
    }

    public function setId(int $value){
        $this->id = $value;
        return $this;
    }

    public function getProductId(): int{
        return $this->productId;
    }

    public function setProductId(int $value){
        $this->productId = $value;
        return $this;
    }

    public function getImage(): string{
        return $this->image;
    }

    public function setImage(string $value) {
        $this->image = $value;
        return $this;
    }

    public function getIsVisible(): bool{
        return $this->isVisible;
    }

    public function setIsVisible(bool $value){
        $this->isVisible = $value;
        return $this;
    }

    public function insert(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->insert("product_image_gallery")
                ->values([
                    "product_id" => "?",
                    "image" => "?",
                    "is_enabled" => "?"
                ])->setParameters([
                    $this->productId,
                    $this->image,
                    $this->isVisible ? 1 : 0
                ])->executeStatement();
            $this->id = $conn->lastInsertId();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function save(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->update("product_image_gallery")
                ->set("product_id", "?")
                ->set("image", "?")
                ->set("is_enabled", "?")
                ->where("id = ?")
                ->setParameters([
                    $this->productId,
                    $this->image,
                    $this->isVisible ? 1 : 0,
                    $this->id
                ])->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    public function delete(Connection $conn)
    {
        try{
            $conn->createQueryBuilder()
                ->delete("product_image_gallery")
                ->where("id = ?")
                ->setParameter(0, $this->id)
                ->executeStatement();
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
    }

    private static function getObject(array $record): ProductImageGallery{
        $object = new ProductImageGallery();
        $object
            ->setId($record["id"])
            ->setProductId($record["product_id"])
            ->setImage($record["image"])
            ->setIsVisible($record["is_enabled"] == 1);
        return $object;
    }

    public static function findById(Connection $conn, int $id): ProductImageGallery{
        $record = false;
        try{
            $record = $conn
                ->createQueryBuilder()
                ->select("*")
                ->from("product_image_gallery")
                ->where("id = ?")
                ->setParameter(0, $id)
                ->executeQuery()
                ->fetchAssociative();
        }catch(Exception $e){
            throw new Exception("Database Operation failed. Please re-try again.");
        }
        if($record === false)
            throw new Exception("No product image found matching specified \"id\"");
        return self::getObject($record);
    }

    public static function findByProductId(Connection $conn, int $productId): array {
        $images = [];
        try{
            $records = $conn->createQueryBuilder()
                ->select("*")
                ->from("product_image_gallery")
                ->where("product_id = ?")
                ->setParameter(0, $productId)
                ->executeQuery()
                ->fetchAllAssociative();
            foreach($records as $record){
                $images[] = self::getObject($record);
            }
        }catch(Exception $e){
            throw new Exception("Database operation failed. Please re-try again.");
        }
        return $images;
    }

}