<?php
namespace Polytropic\EcommBackend\helpers;

use stdClass;
use Throwable;

class JSONResponse extends stdClass {

    public bool $error = false;
    public bool $success = false;
    public ?string $errorMessage = null;

    /**
     * Get the value of error
     */ 
    public function getError(): bool
    {
        return $this->error;
    }

    /**
     * Set the value of error
     *
     * @return  self
     */ 
    public function setError(bool $error): JSONResponse
    {
        $this->error = $error;

        return $this;
    }
    
    /**
     * Get the value of success
     */ 
    public function getSuccess(): bool
    {
        return $this->success;
    }

    /**
     * Set the value of success
     *
     * @return  self
     */ 
    public function setSuccess(bool $success)
    {
        $this->success = $success;
        return $this;
    }
    

    /**
     * Get the value of errorMessage
     */ 
    public function getErrorMessage(): ?string
    {
        return $this->errorMessage;
    }

    /**
     * Set the value of errorMessage
     *
     * @return  self
     */ 
    public function setErrorMessage(?string $errorMessage)
    {
        $this->errorMessage = $errorMessage;

        return $this;
    }

    public function sendResponse(): string
    {
        header("Content-Type: application/json", true);
        http_response_code(200);
        return json_encode($this);
    }

    public function handleError(Throwable $e)
    {
        $this->error = true;
        $this->success = false;
        $this->errorMessage = $e->getMessage();
    }
}