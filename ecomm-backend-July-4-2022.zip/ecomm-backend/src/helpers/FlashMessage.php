<?php
namespace Polytropic\EcommBackend\helpers;

final class FlashMessage{

    public static function setMessage(string $message = null) {
        $messageRepo = $_SESSION["flashMessages"] ?? [];
        if(!is_null($message)){
            $messageRepo[] = $message;
            $_SESSION["flashMessages"] = $messageRepo;
        }
    } 

    public static function showMessage(){
        $messageRepo = $_SESSION["flashMessages"] ?? [];
        if(count($messageRepo) == 0) return "";
        $formattedMessage = '<div class="alert alert-info"><ul style="margin-bottom: 0;">';
        foreach($messageRepo as $message){
            $formattedMessage .= '<li>'.$message.'</li>';
        }
        $formattedMessage .= '</ul></div>';
        $_SESSION["flashMessages"] = [];
        return $formattedMessage;
    }

}