<?php
namespace Polytropic\EcommBackend\helpers;

use Exception;
use stdClass;

class Response extends stdClass{
    public $error = false;
    public $success = false;
    public $errorMessage = null;
    public $successMessage = null;
    public $internalExceptionObject = null;

    public function handleError(Exception $e){
        $this->error = true;
        $this->success = false;
        $this->errorMessage = $e->getMessage();
        $this->internalExceptionObject = $e;
    } 
}