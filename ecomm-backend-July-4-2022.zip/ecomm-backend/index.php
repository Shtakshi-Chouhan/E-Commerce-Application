<?php

use Polytropic\EcommBackend\controllers\CustomerController;
use Polytropic\EcommBackend\controllers\CustomerOrderController;
use Polytropic\EcommBackend\controllers\MainController;
use Polytropic\EcommBackend\controllers\ProductCategoryController;
use Polytropic\EcommBackend\controllers\ProductController;
use Polytropic\EcommBackend\controllers\UserController;
use Polytropic\EcommBackend\models\Product;

ini_set("display_errors", "1"); //should be disabled on production environment 
error_reporting(E_ALL);
date_default_timezone_set("Asia/Kolkata");

require "vendor/autoload.php";

session_start(); //creating or resuming session

const APP_BASE_URL = "http://admin.ecomm.local/";
const VIEW_FOLDER_PATH = __DIR__ . "/src/views/";
const WORKING_MODE = "test";
const UPLOAD_FOLDER = __DIR__ . '/uploads/';
const DATABASE_PARAMS = [
    'dbname' => 'ecomm',
    'user' => 'ecomm-dbuser',
    'password' => 'fzxXEXMrq5]8wuUd',
    'host' => 'localhost',
    'driver' => 'pdo_mysql'
];
const ROUTING_MAP = [
    "admin/login" => ["controller" => MainController::class, "action" => "login"],
    "admin/logout" => ["controller" => MainController::class, "action" => "logout"],
    "admin/dashboard" => ["controller" => MainController::class, "action" => "dashboard"],
    "admin/edit-profile" => ["controller" => MainController::class, "action" => "editProfile"],
    "admin/change-password" => ["controller" => MainController::class, "action" => "changePassword"],
    "admin/manage-users" => ["controller" => UserController::class, "action" => "manage"],
    "admin/user-add" => ["controller" => UserController::class, "action" => "add"],
    "admin/user-edit" => ["controller" => UserController::class, "action" => "edit"],
    "admin/product-category/manage" => ["controller" => ProductCategoryController::class, "action" => "manage"],
    "admin/product-category/add" => ["controller" => ProductCategoryController::class, "action" => "add"],
    "admin/product-category/edit" => ["controller" => ProductCategoryController::class, "action" => "edit"],
    "admin/product/manage" => ["controller" => ProductController::class, "action" => "manage"],
    "admin/product/add" => ["controller" => ProductController::class, "action" => "add"],
    "admin/product/edit" => ["controller" => ProductController::class, "action" => "edit"],
    "admin/product/manage-gallery" => ["controller" => ProductController::class, "action" => "manageGallery"],
    "admin/product/add-gallery-image" => ["controller" => ProductController::class, "action" => "addGalleryImage"],
    "admin/customer/manage" => ["controller" => CustomerController::class, "action" => "manage"],
    "admin/customer/view" => ["controller" => CustomerController::class, "action" => "view"],
    "admin/order/manage" => ["controller" => CustomerOrderController::class, "action" => "manage"],
    "admin/order/view" => ["controller" => CustomerOrderController::class, "action" => "view"],
];

if(!isset($_SESSION["isLoggedIn"])) 
    $_SESSION["isLoggedIn"] = false;

$currentRoute = isset($_GET["route"]) ? $_GET["route"] : "admin/login";

if($currentRoute != "admin/login" &&  $_SESSION["isLoggedIn"] == false){
    header("Location: ".APP_BASE_URL."?route=admin/login", true);
    exit(0);
}

/** Routing */
if(array_key_exists($currentRoute, ROUTING_MAP)){
    $route = ROUTING_MAP[$currentRoute];
    $controllerInstance = new $route["controller"]();
    $controllerInstance->{$route["action"]}();
}else{
    die("Error: No matching route found.");
}