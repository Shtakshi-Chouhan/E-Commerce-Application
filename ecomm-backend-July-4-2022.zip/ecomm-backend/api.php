<?php

use Doctrine\DBAL\DriverManager;
use Polytropic\EcommBackend\APIException\HTTPMethodNotAllowedException;
use Polytropic\EcommBackend\APIException\HTTPNotFoundException;
use Polytropic\EcommBackend\APIException\HTTPServerException;
use Polytropic\EcommBackend\APIException\HTTPUnauthorizedException;
use Polytropic\EcommBackend\controllers\API\CategoryController;
use Polytropic\EcommBackend\controllers\API\MainController;
use Polytropic\EcommBackend\controllers\API\CustomerController;
use Polytropic\EcommBackend\controllers\API\ProductController;
use Polytropic\EcommBackend\models\AppUserToken;
use Throwable;

ini_set("display_errors", "1"); //should be disabled on production environment 
error_reporting(E_ALL);
date_default_timezone_set("Asia/Kolkata");

require "vendor/autoload.php";

const APP_BASE_URL = "http://192.168.50.20";
const WORKING_MODE = "test";
const UPLOAD_FOLDER = __DIR__ . '/uploads/';
const DATABASE_PARAMS = [
    'dbname' => 'ecomm',
    'user' => 'ecomm-dbuser',
    'password' => 'fzxXEXMrq5]8wuUd',
    'host' => 'localhost',
    'driver' => 'pdo_mysql'
];
const ROUTING_MAP = [
    "/login" => [["method" => "POST", "controller" => MainController::class, "action" => "login", "authenticationRequired" => false]],
    "/logout" => [["method" => "POST", "controller" => MainController::class, "action" => "logout", "authenticationRequired" => true]],
    "/customer" => [
        ["method" => "POST", "controller" => CustomerController::class, "action" => "add", "authenticationRequired" => false],
        ["method" => "GET", "controller" => CustomerController::class, "action" => "get", "authenticationRequired" => true],
        ["method" => "PUT", "controller" => CustomerController::class, "action" => "update", "authenticationRequired" => true]
    ],
    "/category" => [
        ["method" => "GET", "controller" => CategoryController::class, "action" => "get", "authenticationRequired" => false]
    ],
    "/list-products" => [
        ["method" => "GET", "controller" => CategoryController::class, "action" => "getProducts", "authenticationRequired" => false]
    ],
    "/product" => [
        ["method" => "GET", "controller" => ProductController::class, "action" => "get", "authenticationRequired" => false]
    ],
    "/billing" => [
        ["method" => "GET", "controller" => CustomerController::class, "action" => "getBillingAddress", "authenticationRequired" => true],
        ["method" => "POST", "controller" => CustomerController::class, "action" => "addBillingAddress", "authenticationRequired" => true],
        ["method" => "PUT", "controller" => CustomerController::class, "action" => "updateBillingAddress", "authenticationRequired" => true],
    ],
    "/shipping" => [
        ["method" => "GET", "controller" => CustomerController::class, "action" => "getShippingAddress", "authenticationRequired" => true],
        ["method" => "POST", "controller" => CustomerController::class, "action" => "addShippingAddress", "authenticationRequired" => true],
        ["method" => "PUT", "controller" => CustomerController::class, "action" => "updateShippingAddress", "authenticationRequired" => true],
    ],
    "/order" => [
        ["method" => "GET", "controller" => OrderController::class, "action" => "get", "authenticationRequired" => true],
        ["method" => "POST", "controller" => OrderController::class, "action" => "create", "authenticationRequired" => true],
        ["method" => "PUT", "controller" => OrderController::class, "action" => "update", "authenticationRequired" => true],
    ]
];

try{
    ob_start(); //start response buffering 
    $currentRoute = $_SERVER["REQUEST_URI"] ?? false;
    if(!$currentRoute)
        throw new HTTPServerException();
    //sanitizing routes
    $currentRoute = parse_url($currentRoute, PHP_URL_PATH);
    //sanitizing query parameters
    $queryString = parse_url($_SERVER["REQUEST_URI"], PHP_URL_QUERY);
    $params = [];
    if(!empty($queryString)){
        $params = [];
        parse_str($queryString, $params);
    }
    //finding matching route
    if(array_key_exists($currentRoute, ROUTING_MAP)){
        $matchingRoute = ROUTING_MAP[$currentRoute];
        $currentRequestMethod = $_SERVER["REQUEST_METHOD"];
        $matchingMethod = null;
        foreach($matchingRoute as $entry){
            if($entry["method"] == $currentRequestMethod){
                $matchingMethod = $entry;
                break;
            }
        }
        //dispatching matched method of matched route
        if(is_null($matchingMethod)){
            throw new HTTPMethodNotAllowedException();
        }else{
            if($matchingMethod["authenticationRequired"]){
                $token = $_SERVER["HTTP_AUTHORIZATION"] ?? false;
                if(empty($token))
                    throw new HTTPUnauthorizedException();
                //validating token and getting userId
                $token = ltrim($token, "Token ");
                $conn = DriverManager::getConnection(DATABASE_PARAMS);
                $record = AppUserToken::findByToken($conn, $token);
                if(!$record)
                    throw new HTTPUnauthorizedException();
                if(($record->getTokenExpiryDate()->getTimestamp() - time()) < 0){
                    $record->delete($conn);
                    throw new HTTPUnauthorizedException();
                }
                $params["token"] = $token;
                $params["customerId"] = $record->getCustomerId();
            }
            $controller = $entry["controller"];
            $action = $entry["action"];
            $controllerInstance = new $controller();
            echo $controllerInstance->{$action}($params);
        }
    }else{
        throw new HTTPNotFoundException();
    }
    $response = ob_get_clean(); // stop buffering and collect and clean buffer
    echo $response;
}catch(HTTPServerException $e){
    http_response_code(500);
}catch(HTTPUnauthorizedException $e){
    http_response_code(401);
}catch(HTTPNotFoundException $e){
    http_response_code(404);
}catch(HTTPMethodNotAllowedException $e){
    http_response_code(405);
}catch(Throwable $e){
    http_response_code(500);
    echo $e->getMessage();
}